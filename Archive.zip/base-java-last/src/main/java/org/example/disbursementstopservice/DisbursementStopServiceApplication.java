package org.example.disbursementstopservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DisbursementStopServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(DisbursementStopServiceApplication.class, args);
    }

}
