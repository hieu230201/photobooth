package org.example.disbursementstopservice.auth.enums;

public enum GrantType {
    PASSWORD_GRANT,
    REFRESH_TOKEN
}