package org.example.disbursementstopservice.auth.enums;

public enum LogLevel {
    TRACE, DEBUG, INFO, ERROR, FATAL
}