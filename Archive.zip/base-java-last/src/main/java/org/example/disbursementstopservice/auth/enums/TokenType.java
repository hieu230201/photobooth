package org.example.disbursementstopservice.auth.enums;

public enum TokenType {
    ACCESS_TOKEN,
    REFRESH_TOKEN,
    CHECK_TOKEN
}