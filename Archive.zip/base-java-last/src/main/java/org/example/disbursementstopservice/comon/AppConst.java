package org.example.disbursementstopservice.comon;

public class AppConst {

    public static String ZONE_NOR ="NOR";
    public static String ZONE_MID ="MID";
    public static String ZONE_SOU ="SOU";
    public static String MESSAGE_FAIL="FALSE";

}
