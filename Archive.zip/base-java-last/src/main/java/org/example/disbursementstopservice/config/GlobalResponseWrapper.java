package org.example.disbursementstopservice.config;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.example.disbursementstopservice.response.ResponseData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.MethodParameter;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;

@ControllerAdvice
public class GlobalResponseWrapper implements ResponseBodyAdvice<Object> {

    @Autowired
    private ObjectMapper objectMapper;

    @Override
    public boolean supports(MethodParameter returnType,
                            Class<? extends HttpMessageConverter<?>> converterType) {
        return !ResponseData.class.isAssignableFrom(returnType.getParameterType());
    }

    @Override
    public Object beforeBodyWrite(Object body,
                                  MethodParameter returnType,
                                  MediaType selectedContentType,
                                  Class<? extends HttpMessageConverter<?>> selectedConverterType,
                                  ServerHttpRequest request,
                                  ServerHttpResponse response) {
        if (body instanceof ResponseEntity<?>) {
            ResponseEntity<?> entity = (ResponseEntity<?>) body;
            Object entityBody = entity.getBody();
            if (entityBody instanceof ResponseData) {
                return entity;
            }
            if (entityBody instanceof String) {
                try {
                    String json = objectMapper.writeValueAsString(new ResponseData<>().success(entityBody));
                    return ResponseEntity.status(entity.getStatusCode())
                            .contentType(MediaType.APPLICATION_JSON)
                            .body(json);
                } catch (JsonProcessingException e) {
                    throw new RuntimeException(e);
                }
            }
            return ResponseEntity
                    .status(entity.getStatusCode())
                    .body(new ResponseData<>().success(entityBody));
        }

        if (body instanceof String) {
            ResponseData<Object> wrapper = new ResponseData<>().success(body);
            try {
                String json = objectMapper.writeValueAsString(wrapper);
                response.getHeaders().setContentType(MediaType.APPLICATION_JSON);
                return json;
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
        if (body instanceof ResponseData) {
            return body;
        }
        return new ResponseData<>().success(body);
    }
}
