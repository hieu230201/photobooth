package org.example.disbursementstopservice.config;

import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponseWrapper;
import java.io.ByteArrayOutputStream;
import java.io.PrintWriter;

public class ResponseWrapper extends HttpServletResponseWrapper {
    private final ByteArrayOutputStream bos = new ByteArrayOutputStream();
    @SuppressWarnings("unused")
    private final PrintWriter writer = new PrintWriter(bos);

    public ResponseWrapper(String uuid, HttpServletResponse response) {
        super(response);
        response.setBufferSize(128 * 1024);
    }

    @Override
    public ServletResponse getResponse() {
        return this;
    }


    public byte[] toByteArray() {
        return bos.toByteArray();
    }
}