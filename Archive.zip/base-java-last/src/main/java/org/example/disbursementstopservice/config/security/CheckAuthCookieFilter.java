package org.example.disbursementstopservice.config.security;

import org.example.disbursementstopservice.auth.enums.LogLevel;
import org.example.disbursementstopservice.comon.SubConstants;
import org.example.disbursementstopservice.config.HttpInfo;
import org.example.disbursementstopservice.config.RequestWrapper;
import org.example.disbursementstopservice.config.ResponseWrapper;
import org.example.disbursementstopservice.logging.LogManage;
import org.example.disbursementstopservice.logging.bases.ILogManage;
import org.apache.logging.log4j.ThreadContext;
import org.example.disbursementstopservice.logging.common.MessageLog;
import org.example.disbursementstopservice.utils.HttpUtil;
import org.example.disbursementstopservice.utils.JsonConvertUtil;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * kiểm tra request của người dùng trước khi nó tới controller
 *
 * @author hieunt
 */

@Component
@Order(Ordered.HIGHEST_PRECEDENCE)
public class CheckAuthCookieFilter extends OncePerRequestFilter {

    private static final ILogManage logManage = LogManage.getLogManage(CheckAuthCookieFilter.class);

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {
        long start = System.currentTimeMillis();
        String uuid = UUID.randomUUID().toString();
        String contentType = request.getContentType();
        boolean isMultipart = contentType != null
                && contentType.toLowerCase().startsWith(MediaType.MULTIPART_FORM_DATA_VALUE);
        HttpServletRequest requestWrapper = request;
        if (!isMultipart) {
            requestWrapper = new RequestWrapper(uuid, start, request);
        }
        ResponseWrapper responseWrapper = new ResponseWrapper(uuid, response);

        if (!isMultipart) {
            HttpInfo httpInfo = HttpUtil.getHttpInfo((RequestWrapper) requestWrapper);
            logRequest(requestWrapper, uuid, httpInfo);
        } else {
            MessageLog messageLog = new MessageLog();
            messageLog.setClassName(this.getClass().getName());
            messageLog.setMethodName("SKIP_BODY|logRequest");
            messageLog.setTraceId(uuid);
            messageLog.setPath(requestWrapper.getRequestURI());
            logManage.log(LogLevel.INFO, messageLog);
        }

        ThreadContext.put(SubConstants.UU_ID, uuid);
        ThreadContext.put(SubConstants.START_TIME, String.valueOf(start));
        ThreadContext.put(SubConstants.PATH, request.getRequestURI());

        try {
            filterChain.doFilter(requestWrapper, responseWrapper);
        } finally {
            String traceId = ThreadContext.get(SubConstants.UU_ID);
            String path = ThreadContext.get(SubConstants.PATH);

            long startTime = 0L;
            if (ThreadContext.get(SubConstants.START_TIME) != null) {
                startTime = Long.parseLong(ThreadContext.get(SubConstants.START_TIME));
            }
            long duration = System.currentTimeMillis() - startTime;
            logResponse(responseWrapper, traceId, path, duration);
            ThreadContext.remove(SubConstants.UU_ID);
            ThreadContext.remove(SubConstants.START_TIME);
            ThreadContext.remove(SubConstants.PATH);
        }
    }

    private void logResponse(
            ResponseWrapper responseWrapper,
            String traceId,
            String path,
            long duration
    ) {
        MessageLog messageLog = new MessageLog();
        messageLog.setClassName(this.getClass().getName());
        messageLog.setMethodName("logResponse");
        messageLog.setTraceId(traceId);
        messageLog.setPath(path);
        messageLog.setDuration(duration);

        try {

            byte[] responseBytes = responseWrapper.toByteArray();

            String responseBody = "";
            if (responseBytes != null && responseBytes.length > 0) {
                responseBody = new String(responseBytes, StandardCharsets.UTF_8);
            }

            Map<String, Object> messageMap = new HashMap<>();
            messageMap.put("status", responseWrapper.getStatus());   // thêm status
            messageMap.put("responseBody", responseBody);

            messageLog.setMessages(messageMap);

            logManage.log(LogLevel.INFO, messageLog);

        } catch (Exception e) {
            messageLog.setMessage("logResponse error");
            messageLog.setException(e);
            logManage.log(LogLevel.ERROR, messageLog);
        }
    }

    private void logRequest(HttpServletRequest request, String uuid, HttpInfo httpInfo) {
        MessageLog messageLog = new MessageLog();
        messageLog.setClassName(this.getClass().getName());
        messageLog.setMethodName(request.getMethod() + "|logRequest");
        messageLog.setTraceId(uuid);
        messageLog.setPath(request.getRequestURI());
        try {
            Map<String, Object> messageMap = new HashMap<>();
            messageMap.put(SubConstants.BODY, JsonConvertUtil.convertObjectToJson(httpInfo));
            messageLog.setMessages(messageMap);
            logManage.log(LogLevel.INFO, messageLog);
        } catch (Exception e) {
            messageLog.setMessage(
                    String.format("logRequest %s - Error: %s", request.getMethod(), request.getRequestURI()));
            messageLog.setException(e);
            logManage.log(LogLevel.ERROR, messageLog);
        }
    }
}