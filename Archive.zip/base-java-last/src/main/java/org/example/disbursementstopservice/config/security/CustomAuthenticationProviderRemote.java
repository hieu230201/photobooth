package org.example.disbursementstopservice.config.security;

import lombok.SneakyThrows;
import org.example.disbursementstopservice.auth.beans.JWTTokenProvider;
import org.example.disbursementstopservice.auth.enums.TokenType;
import org.example.disbursementstopservice.auth.models.UserPrincipal;
import org.example.disbursementstopservice.comon.ErrorCode;
import org.example.disbursementstopservice.entity.RolesEntity;
import org.example.disbursementstopservice.entity.UsersEntity;
import org.example.disbursementstopservice.entity.UsersRolesEntity;
import org.example.disbursementstopservice.exception.CustomServiceBusinessException;
import org.example.disbursementstopservice.repository.RolesRepo;
import org.example.disbursementstopservice.repository.UsersRepo;
import org.example.disbursementstopservice.repository.UsersRolesRepo;
import org.example.disbursementstopservice.response.LoginResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Component
public class CustomAuthenticationProviderRemote implements AuthenticationProvider {
    @Autowired
    public JWTTokenProvider jwtTokenProvider;

    @Autowired
    private UsersRolesRepo usersRolesRepo;

    @Autowired
    private UsersRepo usersRepo;

    @Autowired
    private RolesRepo rolesRepo;

    @Value("${jwt.access.validity}")
    private long jwtAccessValidity;

    @Value("${app.config.appName}")
    private String appName;


    public CustomAuthenticationProviderRemote() {

    }

    @SneakyThrows
    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        String username = authentication.getName();
        String password = authentication.getCredentials().toString();
        UsersEntity user = usersRepo.findByUsername(username);
        if (user == null) {
            throw new CustomServiceBusinessException(ErrorCode.USER_NOT_FOUND);
        }
        List<String> authorizes = getRolesByUser(user.getId());
        LoginResponse loginResponse = new LoginResponse();

        UserPrincipal info = new UserPrincipal(appName, username, user.getId(), null, authorizes,
                UUID.randomUUID().toString(),
                TokenType.ACCESS_TOKEN,
                jwtTokenProvider
                        .generateExpireAt(TokenType.ACCESS_TOKEN));
        loginResponse.setAccessToken(jwtTokenProvider.generateToken(info));
        SecurityContextHolder.getContext().setAuthentication(null);
        if (loginResponse.getAccessToken() != null) {
            return new UsernamePasswordAuthenticationToken(info, password, authorizes.stream().map(SimpleGrantedAuthority::new).collect(Collectors.toList()));
        }
        return null;

    }

    private List<String> getRolesByUser(Long userId) {
        List<String> latestRoles = new ArrayList<>();

        List<UsersRolesEntity> rolesList = usersRolesRepo.findByUserId(userId);
        if (rolesList.isEmpty()) {
            return latestRoles;
        }

        for (UsersRolesEntity role : rolesList) {
            Optional<RolesEntity> roles = rolesRepo.findById(role.getRoleId());
            roles.ifPresent(rolesEntity -> latestRoles.add(rolesEntity.getName()));
        }

        return latestRoles;
    }

    @Override
    public boolean supports(Class authentication) {
        return authentication.equals(UsernamePasswordAuthenticationToken.class);
    }
}


