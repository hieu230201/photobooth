package org.example.disbursementstopservice.config.security;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.example.disbursementstopservice.comon.ErrorCode;
import org.example.disbursementstopservice.response.ResponseData;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;

import javax.servlet.ServletException;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;

/**
 * Handles unauthenticated requests by returning a custom JSON error.
 *
 * @author hieunt
 */
@Component // Marked as a Spring Bean
public class MyAuthenticationEntryPoint implements AuthenticationEntryPoint {

    private final ObjectMapper objectMapper = new ObjectMapper();


    @Override
    public void commence(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response
            , AuthenticationException authException) throws IOException {
        response.setStatus(HttpStatus.UNAUTHORIZED.value());
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setCharacterEncoding(StandardCharsets.UTF_8.name());

        ResponseData<?> responseData;
        if (authException.getMessage().toUpperCase().contains("EXPIRED")) {
            responseData = ResponseData.error(ErrorCode.TOKEN_EXPIRED.getCode(), "Token has expired, please try again!");
        } else {
            responseData = ResponseData.error(ErrorCode.TOKEN_INVALID.getCode(), "Invalid or rejected token.");
        }

        PrintWriter writer = response.getWriter();
        writer.println(objectMapper.writeValueAsString(responseData));
    }
}
