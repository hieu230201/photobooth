package org.example.disbursementstopservice.controller.administration;

import org.example.disbursementstopservice.controller.bases.BaseController;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author HieuNT73
 * @date 2025-11-04
 */

@RestController("/administration/users")
public class UserController extends BaseController {


}
