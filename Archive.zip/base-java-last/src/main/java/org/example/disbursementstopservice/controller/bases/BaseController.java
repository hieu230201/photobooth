package org.example.disbursementstopservice.controller.bases;

import org.example.disbursementstopservice.auth.beans.UserAuthProvider;
import org.example.disbursementstopservice.auth.models.UserPrincipal;
import org.example.disbursementstopservice.logging.LogManage;
import org.example.disbursementstopservice.logging.bases.ILogManage;
import org.example.disbursementstopservice.utils.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Locale;

public class BaseController {

	@Autowired
	UserAuthProvider userAuthProvider;

	protected UserPrincipal getUserPrincipal() {
		return userAuthProvider.getUserPrincipal();
	}
	protected String getUsername() {
		if (userAuthProvider != null && StringUtils.isNotNullAndEmpty(userAuthProvider.getUsername())) {
			return userAuthProvider.getUsername().toLowerCase(Locale.ROOT);
		} else {
			return null;
		}
	}

	protected Long getUserId() {
		return userAuthProvider.getUserId();
	}

}