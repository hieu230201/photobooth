package org.example.disbursementstopservice.controller.login;

import org.example.disbursementstopservice.auth.beans.JWTTokenProvider;
import org.example.disbursementstopservice.auth.models.UserPrincipal;
import org.example.disbursementstopservice.comon.AppConst;
import org.example.disbursementstopservice.comon.ErrorCode;
import org.example.disbursementstopservice.config.security.CustomAuthenticationProviderRemote;
import org.example.disbursementstopservice.request.auth.LoginRequest;
import org.example.disbursementstopservice.response.LoginResponse;
import org.example.disbursementstopservice.response.ResponseData;
import org.example.disbursementstopservice.service.impl.ActiveDirectoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    public JWTTokenProvider jwtTokenProvider;

    @Autowired
    private CustomAuthenticationProviderRemote customAuthenticationProvider;

    @Value("${jwt.access.validity}")
    private long jwtAccessValidity;

    @Autowired
    private ActiveDirectoryService activeDirectoryService;


    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest loginRequest) {
        try {

//            if (loginRequest.getUsername() == null || loginRequest.getUsername().isEmpty() || loginRequest.getPassword() == null || loginRequest.getPassword().isEmpty()) {
//                return ResponseEntity.badRequest().body(new ResponseData<>().error("Vui lòng nhập user hoặc password"));
//            }
//            Integer isLogin = activeDirectoryService.checkLoginWithZone(
//                    loginRequest.getUsername(),
//                    loginRequest.getPassword(),
//                    AppConst.ZONE_NOR,
//                    false,
//                    null
//            );
//
//            if (isLogin != 1) {
//                isLogin = activeDirectoryService.checkLoginWithZone(loginRequest.getUsername(), loginRequest.getPassword(), AppConst.ZONE_MID, false, null);
//            }
//
//            if (isLogin != 1) {
//                isLogin = activeDirectoryService.checkLoginWithZone(loginRequest.getUsername(), loginRequest.getPassword(), AppConst.ZONE_SOU, false, null);
//            }
//
//            if (isLogin != 1) {
//                return ResponseEntity.badRequest().body(new ResponseData<>().error(ErrorCode.USER_NOT_FOUND.getMessage()));
//            }
            Authentication authentication = new UsernamePasswordAuthenticationToken(
                    loginRequest.getUsername(),
                    loginRequest.getPassword()
            );
            Authentication authResult = customAuthenticationProvider.authenticate(authentication);
            if (authResult == null || !(authResult.getPrincipal() instanceof UserPrincipal)) {
                return ResponseEntity.badRequest().body("Invalid credentials");
            }
            UserPrincipal userPrincipal = (UserPrincipal) authResult.getPrincipal();
            LoginResponse loginResponse = new LoginResponse();
            loginResponse.setTokenType("bearer");
            loginResponse.setAccessToken(jwtTokenProvider.generateToken(userPrincipal));
            loginResponse.setExpiresIn(jwtAccessValidity);
            loginResponse.setUsername(loginRequest.getUsername());
            loginResponse.setAuthorizes(userPrincipal.getAuthorities().stream().map(GrantedAuthority::getAuthority).collect(Collectors.toList()));
            return ResponseEntity.ok(loginResponse);

        } catch (AuthenticationException e) {
            return ResponseEntity.badRequest().body("Authentication failed: " + e.getMessage());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
