package org.example.disbursementstopservice.entity;


import org.example.disbursementstopservice.entity.base.BaseEntity;

import javax.persistence.*;

@Entity
@Table(name = "USERS")
public class UsersEntity extends BaseEntity {

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Basic
    @Column(name = "USERNAME")
    private String username;

    @Basic
    @Column(name = "FULL_NAME")
    private String fullname;

    @Basic
    @Column(name = "EMAIL")
    private String email;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

}
