package org.example.disbursementstopservice.logging;


import org.apache.log4j.Logger;
import org.example.disbursementstopservice.auth.enums.LogLevel;
import org.example.disbursementstopservice.logging.bases.ILogManage;
import org.example.disbursementstopservice.logging.common.MessageLog;

public class LogManage implements ILogManage {
    private final Logger logger;

    private LogManage(Class<?> clazz) {
        this.logger = Logger.getLogger(clazz);
    }

    public static ILogManage getLogManage(Class<?> clazz) {
        return new LogManage(clazz);
    }

    @Override
    public void log(LogLevel level, MessageLog log) {
        if (log.getClassName() == null) {
            log.setClassName(logger.getName());
        }
        switch (level) {
            case TRACE -> logger.trace(log, log.getException());
            case DEBUG -> logger.debug(log, log.getException());
            case INFO  -> logger.info(log, log.getException());
            case ERROR -> logger.error(log, log.getException());
            case FATAL -> logger.fatal(log, log.getException());
        }
    }

}