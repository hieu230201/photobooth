package org.example.disbursementstopservice.logging.bases;


import org.example.disbursementstopservice.auth.enums.LogLevel;
import org.example.disbursementstopservice.logging.LogManage;
import org.example.disbursementstopservice.logging.common.MessageLog;

public interface ILogManage {
    void log(LogLevel level, MessageLog messageLog);
}