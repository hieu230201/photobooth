package org.example.disbursementstopservice.logging.common;

import lombok.Getter;
import lombok.Setter;
import org.example.disbursementstopservice.utils.StringBuilderPlus;
import org.example.disbursementstopservice.utils.StringUtils;

import java.text.MessageFormat;
import java.util.Map;
import java.util.UUID;

@Getter
@Setter
public class MessageLog {

    private String traceId = UUID.randomUUID().toString();
    private String className;
    private String methodName;
    private String message;
    private Map<String, ?> params;
    private Map<String, ?> messages;
    private Exception exception;
    private Long duration;
    private String path;

    public static MessageLog of(String message) {
        MessageLog log = new MessageLog();
        log.setMessage(message);
        return log;
    }

    @Override
    public String toString() {
        StringBuilderPlus parameterBuilder = new StringBuilderPlus();
        if (params != null) {
            for (Map.Entry<String, ?> entry : params.entrySet()) {
                parameterBuilder.appendLine(MessageFormat.format("    + {0}: {1}", entry.getKey(), entry.getValue()));
            }
        }
        StringBuilderPlus strBuilder = new StringBuilderPlus();
        strBuilder.appendLine();
        strBuilder.appendLine("- Id: " + (StringUtils.isBlank(traceId) ? UUID.randomUUID() : traceId));
        strBuilder.appendLine("- Classname: " + className);
        strBuilder.appendLine("- MethodName: " + methodName);
        if (parameterBuilder.length() > 0) {
            strBuilder.appendLine("- Parameters: ");
            strBuilder.append(parameterBuilder.toString());
        }
        StringBuilderPlus messagesBuilder = new StringBuilderPlus();
        if (messages != null) {
            for (Map.Entry<String, ?> entry : messages.entrySet()) {
                messagesBuilder.appendLine(MessageFormat.format("    + {0}: {1}", entry.getKey(), entry.getValue()));
            }
        }
        if (messagesBuilder.length() > 0) {
            strBuilder.appendLine("- Messages: ");
            strBuilder.append(messagesBuilder.toString());
        }
        return strBuilder.toString();
    }


}