package org.example.disbursementstopservice.model;

public interface BaseObjectInfo {
    String getObjectName();
}
