package org.example.disbursementstopservice.repository;

import org.example.disbursementstopservice.entity.RolesEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RolesRepo extends JpaRepository<RolesEntity, Long> {
}
