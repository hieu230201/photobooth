package org.example.disbursementstopservice.repository;

import org.example.disbursementstopservice.entity.UsersEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UsersRepo extends JpaRepository<UsersEntity, Long> {
    UsersEntity findByUsername(String username);

    UsersEntity findByEmail(String email);

}
