package org.example.disbursementstopservice.repository;

import org.example.disbursementstopservice.entity.UsersRolesEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface UsersRolesRepo extends JpaRepository<UsersRolesEntity, Long> {
    List<UsersRolesEntity> findByUserId(Long id);
}
