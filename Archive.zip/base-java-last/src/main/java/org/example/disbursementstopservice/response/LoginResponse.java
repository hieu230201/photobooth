package org.example.disbursementstopservice.response;


import java.util.List;

public class LoginResponse {
    private String accessToken;
    private String refreshToken;
    private String tokenType;
    private String username;
    private List<String> authorizes;
    private Long expiresIn;

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public String getRefreshToken() {
        return refreshToken;
    }

    public void setRefreshToken(String refreshToken) {
        this.refreshToken = refreshToken;
    }

    public String getTokenType() {
        return tokenType;
    }

    public void setTokenType(String tokenType) {
        this.tokenType = tokenType;
    }

    public List<String> getAuthorizes() {
        return authorizes;
    }

    public void setAuthorizes(List<String> authorizes) {
        this.authorizes = authorizes;
    }

    public Long getExpiresIn() {
        return expiresIn;
    }

    public void setExpiresIn(Long expiresIn) {
        this.expiresIn = expiresIn;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}