package org.example.disbursementstopservice.response;


import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @param <T>
 * @author hieunt
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class ResponseData<T> implements Serializable {

    private static final long serialVersionUID = -5435628560059929L;

    private Integer status;
    private String message;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS", timezone = "GMT+7")
    private final Date timeResponse = new Date();

    private String traceId;
    private long duration;
    private String path;

    private T data;
    private String error;


    public static <T> ResponseData<T> success(T data) {
        ResponseData<T> res = new ResponseData<>();
        res.status = 200;
        res.message = "Success";
        res.data = data;
        return res;
    }

    public static <T> ResponseData<T> error(int status, String message) {
        ResponseData<T> res = new ResponseData<>();
        res.status = status;
        res.message = message;
        return res;
    }
}
