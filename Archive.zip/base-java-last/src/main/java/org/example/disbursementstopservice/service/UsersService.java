package org.example.disbursementstopservice.service;


import org.example.disbursementstopservice.entity.UsersEntity;

public interface UsersService {
    UsersEntity createOrUpdateUser(UsersEntity user);

    UsersEntity findUserByEmail(String email);

    UsersEntity findUserByUsername(String username);

    UsersEntity deleteUser(Long id);

}
