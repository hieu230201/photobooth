package org.example.disbursementstopservice.service.impl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.example.disbursementstopservice.utils.LoginResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.*;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;

@Service
public class ActiveDirectoryService {

    private static final Logger logger = LogManager.getLogger(ActiveDirectoryService.class);

    @Value("${ldap.context.factory:com.sun.jndi.ldap.LdapCtxFactory}")
    private String contextFactory;

    @Value("${ldap.connection.url:ldap://%s.tpb.com/}")
    private String connectionUrlPattern;

    @Value("${ldap.user.base:DC=%s,DC=TPB,DC=COM}")
    private String userBasePattern;

    private static final String MEMBER_OF = "memberOf";
    private static final String[] ATTR_IDS_TO_SEARCH = new String[]{MEMBER_OF};
    private static final String SEARCH_BY_SAM_ACCOUNT_NAME = "(sAMAccountName=%s)";

    /**
     * Xác thực user qua LDAP.
     */
    public int checkLoginWithZone(String username, String password, String zone,
                                  boolean checkGroupAccepted, List<String> listGroupAccepted) throws NamingException {

        String connectionName = username + "@" + zone + ".TPB.COM";
        String conURL = String.format(connectionUrlPattern, zone);

        Hashtable<String, String> env = new Hashtable<>();
        env.put(Context.INITIAL_CONTEXT_FACTORY, contextFactory);
        env.put(Context.PROVIDER_URL, conURL);
        env.put(Context.SECURITY_PRINCIPAL, connectionName);
        env.put(Context.SECURITY_CREDENTIALS, password);

        int returnResponse = LoginResponse.ReponseCode.USER_PASS_FAIL.getValue();

        // thử kết nối tối đa 3 lần
        for (int attempt = 1; attempt <= 3; attempt++) {
            DirContext context = null;
            try {
                context = new InitialDirContext(env);
                returnResponse = LoginResponse.ReponseCode.SUCCESS_LOGIN.getValue();

                // Nếu không cần check group thì kết thúc luôn
                if (!checkGroupAccepted) {
                    return returnResponse;
                }

                // Kiểm tra group của user
                return checkUserGroups(context, username, zone, listGroupAccepted);

            } catch (Exception e) {
                if (e.getCause() instanceof java.net.ConnectException && attempt < 3) {
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException ignored) {
                    }
                } else {
                    returnResponse = LoginResponse.ReponseCode.USER_PASS_FAIL.getValue();
                }
            }
        }

        return returnResponse;
    }

    /**
     * Kiểm tra user thuộc nhóm được phép hay không.
     */
    private int checkUserGroups(DirContext context, String username, String zone,
                                List<String> listGroupAccepted) throws NamingException {
        String filter = String.format(SEARCH_BY_SAM_ACCOUNT_NAME, username);
        String userBaseSearch = String.format(userBasePattern, zone);
        SearchControls constraints = new SearchControls();
        constraints.setSearchScope(SearchControls.SUBTREE_SCOPE);
        constraints.setReturningAttributes(ATTR_IDS_TO_SEARCH);
        NamingEnumeration<SearchResult> results = context.search(userBaseSearch, filter, constraints);
        if (results == null || !results.hasMore()) {
            return LoginResponse.ReponseCode.USER_NOT_PERMISSION.getValue();
        }
        SearchResult result = results.next();
        Attribute attr = result.getAttributes().get(MEMBER_OF);
        if (attr == null) {
            return LoginResponse.ReponseCode.USER_NOT_PERMISSION.getValue();
        }
        while (attr.getAll().hasMoreElements()) {
            String groupName = getCN(attr.getAll().nextElement().toString());
            for (String acceptedGroup : listGroupAccepted) {
                if (acceptedGroup.equalsIgnoreCase(groupName)) {
                    return LoginResponse.ReponseCode.SUCCESS_LOGIN.getValue();
                }
            }
        }
        return LoginResponse.ReponseCode.USER_NOT_PERMISSION.getValue();
    }

    private static String getCN(String cnName) {
        if (cnName == null) return null;
        if (cnName.toUpperCase().startsWith("CN=")) {
            cnName = cnName.substring(3);
        }
        int position = cnName.indexOf(',');
        return (position == -1) ? cnName : cnName.substring(0, position);
    }
}
