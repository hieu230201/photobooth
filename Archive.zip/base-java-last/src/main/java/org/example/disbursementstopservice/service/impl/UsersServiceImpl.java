package org.example.disbursementstopservice.service.impl;

import org.example.disbursementstopservice.entity.UsersEntity;
import org.example.disbursementstopservice.repository.UsersRepo;
import org.example.disbursementstopservice.service.UsersService;
import org.example.disbursementstopservice.utils.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UsersServiceImpl implements UsersService {

    @Autowired
    private UsersRepo usersRepo;

    @Override
    public UsersEntity createOrUpdateUser(UsersEntity user) {
        if (user.getId() != null) {
            UsersEntity oldUser = usersRepo.findById(user.getId()).get();
            copyUnchangedFields(user, oldUser);
        }
        return usersRepo.save(user);
    }

    @Override
    public UsersEntity findUserByEmail(String email) {
        if (StringUtils.isNullOrEmpty(email)) {
            return null;
        }
        return usersRepo.findByEmail(email);
    }

    @Override
    public UsersEntity findUserByUsername(String username) {
        if (StringUtils.isNullOrEmpty(username)) {
            return null;
        }
        return usersRepo.findByUsername(username);
    }

    @Override
    public UsersEntity deleteUser(Long id) {
        if (id == null) {
            return null;
        }
        UsersEntity user = usersRepo.findById(id).orElse(null);
        if (user != null) {
            usersRepo.delete(user);
        }
        return user;
    }

    private void copyUnchangedFields(UsersEntity newUser, UsersEntity oldUser) {
        newUser.setCreatedDate(oldUser.getCreatedDate());
        newUser.setCreatedBy(oldUser.getCreatedBy());
    }
}
