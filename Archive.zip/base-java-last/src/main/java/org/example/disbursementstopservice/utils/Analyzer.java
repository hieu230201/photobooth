package org.example.disbursementstopservice.utils;

import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;

public class Analyzer {

    public static Map<Character, Integer> countLetters(String content) {
        Map<Character, Integer> charCount = new HashMap<>();
        for (char ch : content.toLowerCase().toCharArray()) {
            if (Character.isLetter(ch)) {
                charCount.put(ch, charCount.getOrDefault(ch, 0) + 1);
            }
        }
        return charCount;
    }

    public static Map<String, Integer> countWords(String content) {
        Map<String, Integer> wordCount = new HashMap<>();
        StringTokenizer tokenizer = new StringTokenizer(content.toLowerCase(), " .,!?;:-()\"'\n\t");
        while (tokenizer.hasMoreTokens()) {
            String word = tokenizer.nextToken();
            wordCount.put(word, wordCount.getOrDefault(word, 0) + 1);
        }
        return wordCount;
    }

    public static void main(String[] args) {
        String input = "hello world";

        Map<String, Integer> words = countWords(input);
        Map<Character, Integer> letters = countLetters(input);

        System.out.println(words);
        System.out.println(letters);
    }
}
