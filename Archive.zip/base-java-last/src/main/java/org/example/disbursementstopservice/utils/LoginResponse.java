package org.example.disbursementstopservice.utils;

public class LoginResponse {
    public enum ReponseCode{
        USER_PASS_FAIL(-2) ,USER_NOT_PERMISSION(-3),CONNECTION_TIMEOUT(-4), SUCCESS_LOGIN(1);
        private int values;
        private ReponseCode(int value) {
            this.values = value;
        }
        public int getValue() { return values; }
    }
}
