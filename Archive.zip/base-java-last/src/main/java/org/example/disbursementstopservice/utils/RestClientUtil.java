package org.example.disbursementstopservice.utils;

import org.example.disbursementstopservice.auth.enums.LogLevel;
import org.example.disbursementstopservice.comon.ErrorCode;
import org.example.disbursementstopservice.comon.SubConstants;
import org.example.disbursementstopservice.exception.CustomServiceBusinessException;
import org.example.disbursementstopservice.logging.LogManage;
import org.example.disbursementstopservice.logging.bases.ILogManage;
import org.example.disbursementstopservice.logging.common.MessageLog;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

@Component
public class RestClientUtil {
    private final RestTemplate restTemplate;

    private static final ILogManage logManage = LogManage.getLogManage(RestClientUtil.class);

    public RestClientUtil(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public <T, R> ResponseEntity<R> sendRequest(
            String url,
            HttpMethod method,
            HttpHeaders headers,
            T requestBody,
            Class<R> responseType
    ) throws CustomServiceBusinessException {

        HttpEntity<T> requestEntity = new HttpEntity<>(requestBody, headers);
        long startTime = System.currentTimeMillis();
        Map<String, String> messageMap = new HashMap<>();
        logRequest(method, url, null, requestEntity);
        try {
            ResponseEntity<R> response = restTemplate.exchange(
                    url,
                    method,
                    requestEntity,
                    responseType
            );
            logResponse(url, headers.toSingleValueMap(), response, startTime);
            return response;
        } catch (HttpStatusCodeException e) {
            messageMap.put(SubConstants.BODY, e.getResponseBodyAsString());
            messageMap.put(SubConstants.PARAMS, JsonConvertUtil.convertObjectToJson(requestEntity));
            messageMap.put(SubConstants.PATH, url);

//            MessageLog messageLog = new MessageLog(null, this.getClass().getName(), method.name(),
//                    null, messageMap, null);
            MessageLog messageLog = new MessageLog();
            messageLog.setPath(url);
            messageLog.setDuration(System.currentTimeMillis() - startTime);

            logManage.log(LogLevel.ERROR, messageLog);
            throw new CustomServiceBusinessException(formatError(e.getResponseBodyAsString()), ErrorCode.CALL_API_HTTP_ERROR);
        } catch (Exception e) {
            throw new RuntimeException("Unexpected error during REST call: " + e.getMessage(), e);
        }
    }

    public <T, R> ResponseEntity<R> sendRequest(
            String url,
            HttpMethod method,
            HttpHeaders headers,
            T requestBody,
            ParameterizedTypeReference<R> responseType
    ) throws CustomServiceBusinessException {

        HttpEntity<T> requestEntity = new HttpEntity<>(requestBody, headers);
        long startTime = System.currentTimeMillis();
        Map<String, String> messageMap = new HashMap<>();
        logRequest(method, url, null, requestEntity);
        try {
            ResponseEntity<R> response = restTemplate.exchange(
                    url,
                    method,
                    requestEntity,
                    responseType
            );
            logResponse(url, headers.toSingleValueMap(), response, startTime);
            return response;
        } catch (HttpStatusCodeException e) {
            messageMap.put(SubConstants.BODY, e.getResponseBodyAsString());
            messageMap.put(SubConstants.PARAMS, JsonConvertUtil.convertObjectToJson(requestEntity));
            messageMap.put(SubConstants.PATH, url);

//            MessageLog messageLog = new MessageLog(null, this.getClass().getName(), method.name(),
//                    null, messageMap, null);
            MessageLog messageLog = new MessageLog();
           // messageLog.setPath(url);
            messageLog.setDuration(System.currentTimeMillis() - startTime);

            logManage.log(LogLevel.ERROR, messageLog);
            throw new CustomServiceBusinessException(formatError(e.getResponseBodyAsString()), ErrorCode.CALL_API_HTTP_ERROR);
        } catch (Exception e) {
            throw new RuntimeException("Unexpected error during REST call: " + e.getMessage(), e);
        }
    }


    protected <T> void logResponse(String uri, Map<String, String> headerParams, ResponseEntity<T> response,
                                   Long startTime) {
        String clientMessageId = null;
        try {
            if (headerParams != null && (headerParams.containsKey(SubConstants.CLIENT_MESSAGE_ID)))
                clientMessageId = headerParams.get(SubConstants.CLIENT_MESSAGE_ID);
            MessageLog messageLog = getMessageLog(clientMessageId, "ApiUtils - logResponse");
            if (startTime != null)
                messageLog.setDuration(System.currentTimeMillis() - startTime);
            //messageLog.setParameters(headerParams);
            Map<String, Object> messageMap = new HashMap<>();
            messageMap.put(SubConstants.PATH, uri);
            messageMap.put(SubConstants.CLIENT_MESSAGE_ID, clientMessageId);
            if (response != null) {
                messageMap.put(SubConstants.STATUS_CODE, response.getStatusCode());
                messageMap.put(SubConstants.HEADERS, JsonConvertUtil.convertObjectToJson(response.getHeaders()));
                messageMap.put(SubConstants.BODY, JsonConvertUtil.convertObjectToJson(response.getBody()));
            }

            //messageLog.setMessages(messageMap);
//            if (httpServletRequest != null)
            messageLog.setPath(uri);
            logManage.log(LogLevel.INFO, messageLog);
        } catch (Exception e) {
            //logManage.log(LogLevel.ERROR, String.format("logResponse Exception:id=%s,fullstack=%s", clientMessageId, e.toString()));
        }

    }


    protected void logRequest(HttpMethod httpMethod, String url, Map<String, ?> params,
                              HttpEntity<?> entity) {
        String clientMessageId = null;
        try {
            MessageLog messageLog = getMessageLog(clientMessageId, httpMethod.name() + "|RestClientUtil - logRequest");
            //messageLog.setParameters(params);

            Map<String, Object> messageMap = new HashMap<>();
            messageMap.put(SubConstants.PATH, url);
            messageMap.put(SubConstants.CLIENT_MESSAGE_ID, clientMessageId);
            if (entity != null) {
                messageMap.put(SubConstants.HEADERS, JsonConvertUtil.convertObjectToJson(entity.getHeaders()));
                messageMap.put(SubConstants.BODY, JsonConvertUtil.convertObjectToJson(entity.getBody()));
            }
            messageMap.put(SubConstants.PARAMS, JsonConvertUtil.convertObjectToJson(params));

           // messageLog.setMessages(messageMap);
            messageLog.setPath(url);
            logManage.log(LogLevel.INFO, messageLog);
        } catch (Exception e) {
            //logManage.error(String.format("logRequest Exception:id=%s,fullstack=%s", clientMessageId, e.toString()), e);
        }
    }

    protected MessageLog getMessageLog(String clientMessageId, String methodName) {
        MessageLog messageLog = new MessageLog();
        messageLog.setClassName(this.getClass().getName());
        messageLog.setMethodName(methodName);
        messageLog.setTraceId(clientMessageId);
        return messageLog;
    }

    protected String formatError(String response) {
        try {
            StringBuilderPlus message = new StringBuilderPlus();
            JSONObject objJson = new JSONObject(response);
            message.append("Trạng thái: ");
            message.appendNewLine(String.format("%s", objJson.getInt("status")));
            message.appendNewLine(objJson.getString("error"));
            message.appendNewLine(objJson.getString("soaErrorDesc"));
            //message.appendNewLine("RequestId: " + objJson.getString(SubConstants.CLIENT_MESSAGE_ID));

            return message.toString();
        } catch (JSONException e) {
            return response;
        }
    }
}
