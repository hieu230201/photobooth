package org.example.disbursementstopservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DisbursementStopServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
