# API Usage Guide

Tai lieu nay duoc cap nhat theo source hien tai trong project, bao gom:

- API auth tai [AuthController.java](/Users/trunghieu/Desktop/code/codexdemo/src/main/java/com/example/codexdemo/controller/AuthController.java)
- API CRUD user tai [UserController.java](/Users/trunghieu/Desktop/code/codexdemo/src/main/java/com/example/codexdemo/controller/UserController.java)
- API OCR/KSS flow tai [OcrIntegrationController.java](/Users/trunghieu/Desktop/code/codexdemo/src/main/java/com/example/codexdemo/controller/OcrIntegrationController.java)

## Base URL

Mac dinh:

```text
http://localhost:8080
```

Prefix API:

```text
/api/v1
```

## Chay project

```bash
./mvnw spring-boot:run
```

Project dang dung MySQL theo cau hinh tai [application.properties](/Users/trunghieu/Desktop/code/codexdemo/src/main/resources/application.properties).

## Tai khoan mac dinh de test

Du lieu seed duoc tao trong [DataInitializer.java](/Users/trunghieu/Desktop/code/codexdemo/src/main/java/com/example/codexdemo/config/DataInitializer.java):

- Username: `admin`
- Password: `Admin@123`

## Header chung

Header co the dung cho moi request:

```http
Content-Type: application/json
X-Trace-Id: your-trace-id-001
```

Neu khong truyen `X-Trace-Id`, he thong se tu sinh. Xem [TraceIdFilter.java](/Users/trunghieu/Desktop/code/codexdemo/src/main/java/com/example/codexdemo/security/TraceIdFilter.java).

## OCR/KSS Flow

Module nay gom 2 endpoint theo tai lieu OCR async:

1. `POST /api/v1/ocr/kss/async`: nhan file, `refNo`, `type`, sau do backend tu goi login DEV1.IT, upload file, va submit OCR async cho tung `fileId`.
2. `POST /SaveResponseGenAI`: endpoint callback de AI-OCR day ket qua ve he thong.

### Submit OCR async flow

- Method: `POST`
- URL: `http://localhost:8080/api/v1/ocr/kss/async`
- Content-Type: `multipart/form-data`
- Auth: khong yeu cau local JWT

Form-data:

- `files`: danh sach file can OCR
- `refNo`: refNo cua FCC
- `type`: mot trong cac gia tri nhu `dn_chuyenvon`, `lenh_chuyenvon`, `bbpc_ttq`, `lenh_dieuchuyen`

curl:

```bash
curl --request POST 'http://localhost:8080/api/v1/ocr/kss/async' \
  --header 'X-Trace-Id: ocr-flow-001' \
  --form 'refNo=FCC-001' \
  --form 'type=dn_chuyenvon' \
  --form 'files=@"/path/to/file-1.pdf"' \
  --form 'files=@"/path/to/file-2.pdf"'
```

Response thanh cong:

```json
{
  "code": "00",
  "message": "OCR asynchronous flow submitted successfully",
  "data": {
    "refNo": "FCC-001",
    "type": "dn_chuyenvon",
    "submissions": [
      {
        "requestId": "8b504780-e80a-470a-8d65-c40ade737a64",
        "refNo": "FCC-001",
        "fileId": "3e8b52f8-f024-4343-aba1-afaea416a90a",
        "sourceFileName": "file-1.pdf",
        "callbackDocumentType": "PHIEU_DE_NGHI_DIEU_CHUYEN_VON"
      }
    ]
  },
  "traceId": "ocr-flow-001",
  "timestamp": "2026-04-06T09:00:00Z"
}
```

Cau hinh gateway ngoai nam trong [application.properties](/Users/trunghieu/Desktop/code/codexdemo/src/main/resources/application.properties) voi prefix `integration.ocr.gateway.*`.

### Receive OCR callback

- Method: `POST`
- URL: `http://localhost:8080/SaveResponseGenAI`
- Content-Type: `application/json`

Header:

```http
user: ecm
Transactionsid: 12222
Password: <callback-password>
```

Response thanh cong:

```json
{
  "code": "00",
  "message": "OCR callback received successfully",
  "data": {
    "transactionId": "12222",
    "refNo": "FCC-001",
    "documentType": "PHIEU_DE_NGHI_DIEU_CHUYEN_VON",
    "callbackStatus": "success"
  },
  "traceId": "callback-trace",
  "timestamp": "2026-04-06T09:05:00Z"
}
```

## Auth Flow

1. Goi `POST /api/v1/auth/login` de lay `accessToken`.
2. Gan token vao header `Authorization: Bearer <accessToken>` khi goi API can xac thuc.
3. Goi `POST /api/v1/auth/logout` de revoke token hien tai.
4. Toan bo API CRUD user yeu cau token cua user co role `ADMIN`.

## 1. Login

- Method: `POST`
- URL: `http://localhost:8080/api/v1/auth/login`
- Auth: khong can token

Request body:

```json
{
  "username": "admin",
  "password": "Admin@123"
}
```

curl:

```bash
curl --request POST 'http://localhost:8080/api/v1/auth/login' \
  --header 'Content-Type: application/json' \
  --header 'X-Trace-Id: login-demo-001' \
  --data '{
    "username": "admin",
    "password": "Admin@123"
  }'
```

Response thanh cong:

```json
{
  "code": "00",
  "message": "Login successful",
  "data": {
    "accessToken": "<jwt-token>",
    "tokenType": "Bearer",
    "issuer": "codexdemo-auth",
    "subject": "admin",
    "jwtId": "5f0d7f8b-1111-2222-3333-abcdefabcdef",
    "issuedAt": "2026-04-05T09:00:00Z",
    "expiresAt": "2026-04-05T09:15:00Z",
    "user": {
      "id": 1,
      "username": "admin",
      "fullName": "System Administrator",
      "roles": [
        "ADMIN",
        "USER"
      ]
    }
  },
  "traceId": "login-demo-001",
  "timestamp": "2026-04-05T09:00:00Z"
}
```

Luu y:

- `accessToken` co TTL `900` giay, theo [application.properties](/Users/trunghieu/Desktop/code/codexdemo/src/main/resources/application.properties).
- `tokenType` luon la `Bearer`.

Response loi sai username/password:

```json
{
  "errorCode": "02",
  "message": "Invalid username or password",
  "traceId": "login-demo-001",
  "timestamp": "2026-04-05T09:00:05Z"
}
```

Response loi validate:

```json
{
  "errorCode": "01",
  "message": "username must not be blank; password must not be blank",
  "traceId": "login-demo-001",
  "timestamp": "2026-04-05T09:00:10Z"
}
```

## 2. Logout

- Method: `POST`
- URL: `http://localhost:8080/api/v1/auth/logout`
- Auth: can `Authorization: Bearer <accessToken>`

Header:

```http
Authorization: Bearer <accessToken>
Content-Type: application/json
X-Trace-Id: logout-demo-001
```

curl:

```bash
curl --request POST 'http://localhost:8080/api/v1/auth/logout' \
  --header 'Authorization: Bearer <accessToken>' \
  --header 'Content-Type: application/json' \
  --header 'X-Trace-Id: logout-demo-001'
```

Response thanh cong:

```json
{
  "code": "00",
  "message": "Logout successful",
  "data": {
    "status": "LOGGED_OUT"
  },
  "traceId": "logout-demo-001",
  "timestamp": "2026-04-05T09:05:00Z"
}
```

Response loi khi thieu token:

```json
{
  "errorCode": "03",
  "message": "Access token is required",
  "traceId": "logout-demo-001",
  "timestamp": "2026-04-05T09:05:05Z"
}
```

Response loi khi token khong hop le:

```json
{
  "errorCode": "03",
  "message": "Invalid access token",
  "traceId": "logout-demo-001",
  "timestamp": "2026-04-05T09:05:10Z"
}
```

## 3. User CRUD

Tat ca endpoint trong nhom nay nam o prefix:

```text
/api/v1/users
```

Tat ca deu yeu cau:

```http
Authorization: Bearer <admin-access-token>
```

Va chi role `ADMIN` moi goi duoc, do controller co [@PreAuthorize("hasRole('ADMIN')")](/Users/trunghieu/Desktop/code/codexdemo/src/main/java/com/example/codexdemo/controller/UserController.java#L26).

### 3.1 Create user

- Method: `POST`
- URL: `http://localhost:8080/api/v1/users`
- Auth: `Bearer token` cua admin

Request body:

```json
{
  "username": "john.doe",
  "password": "Password@123",
  "fullName": "John Doe",
  "enabled": true,
  "roles": [
    "USER"
  ]
}
```

Rules:

- `username`: khong duoc rong, toi da 50 ky tu
- `password`: 8-100 ky tu
- `fullName`: khong duoc rong, toi da 100 ky tu
- `roles`: khong duoc rong
- Role hop le hien tai: `ADMIN`, `USER`

curl:

```bash
curl --request POST 'http://localhost:8080/api/v1/users' \
  --header 'Authorization: Bearer <admin-access-token>' \
  --header 'Content-Type: application/json' \
  --header 'X-Trace-Id: create-user-001' \
  --data '{
    "username": "john.doe",
    "password": "Password@123",
    "fullName": "John Doe",
    "enabled": true,
    "roles": ["USER"]
  }'
```

Response thanh cong:

```json
{
  "code": "00",
  "message": "User created successfully",
  "data": {
    "id": 2,
    "username": "john.doe",
    "fullName": "John Doe",
    "enabled": true,
    "roles": [
      "USER"
    ],
    "createdAt": "2026-04-06T09:10:00Z",
    "updatedAt": "2026-04-06T09:10:00Z"
  },
  "traceId": "create-user-001",
  "timestamp": "2026-04-06T09:10:00Z"
}
```

Response loi trung username:

```json
{
  "errorCode": "05",
  "message": "Username already exists",
  "traceId": "create-user-001",
  "timestamp": "2026-04-06T09:10:05Z"
}
```

### 3.2 Get all users

- Method: `GET`
- URL: `http://localhost:8080/api/v1/users`
- Auth: `Bearer token` cua admin

curl:

```bash
curl --request GET 'http://localhost:8080/api/v1/users' \
  --header 'Authorization: Bearer <admin-access-token>' \
  --header 'X-Trace-Id: get-users-001'
```

Response thanh cong:

```json
{
  "code": "00",
  "message": "Users fetched successfully",
  "data": [
    {
      "id": 1,
      "username": "admin",
      "fullName": "System Administrator",
      "enabled": true,
      "roles": [
        "ADMIN",
        "USER"
      ],
      "createdAt": "2026-04-06T09:00:00Z",
      "updatedAt": "2026-04-06T09:00:00Z"
    },
    {
      "id": 2,
      "username": "john.doe",
      "fullName": "John Doe",
      "enabled": true,
      "roles": [
        "USER"
      ],
      "createdAt": "2026-04-06T09:10:00Z",
      "updatedAt": "2026-04-06T09:10:00Z"
    }
  ],
  "traceId": "get-users-001",
  "timestamp": "2026-04-06T09:11:00Z"
}
```

### 3.3 Get user by id

- Method: `GET`
- URL: `http://localhost:8080/api/v1/users/{id}`
- Auth: `Bearer token` cua admin

curl:

```bash
curl --request GET 'http://localhost:8080/api/v1/users/2' \
  --header 'Authorization: Bearer <admin-access-token>' \
  --header 'X-Trace-Id: get-user-by-id-001'
```

Response thanh cong:

```json
{
  "code": "00",
  "message": "User fetched successfully",
  "data": {
    "id": 2,
    "username": "john.doe",
    "fullName": "John Doe",
    "enabled": true,
    "roles": [
      "USER"
    ],
    "createdAt": "2026-04-06T09:10:00Z",
    "updatedAt": "2026-04-06T09:10:00Z"
  },
  "traceId": "get-user-by-id-001",
  "timestamp": "2026-04-06T09:12:00Z"
}
```

Response loi khong tim thay:

```json
{
  "errorCode": "04",
  "message": "User not found",
  "traceId": "get-user-by-id-001",
  "timestamp": "2026-04-06T09:12:05Z"
}
```

### 3.4 Update user

- Method: `PUT`
- URL: `http://localhost:8080/api/v1/users/{id}`
- Auth: `Bearer token` cua admin

Request body:

```json
{
  "username": "john.doe",
  "password": "NewPassword@123",
  "fullName": "John Doe Updated",
  "enabled": true,
  "roles": [
    "USER",
    "ADMIN"
  ]
}
```

Luu y:

- `password` trong update co the bo trong request.
- Neu truyen `password`, phai dai 8-100 ky tu.
- Neu khong muon doi password, co the gui `null` hoac bo field nay.

curl:

```bash
curl --request PUT 'http://localhost:8080/api/v1/users/2' \
  --header 'Authorization: Bearer <admin-access-token>' \
  --header 'Content-Type: application/json' \
  --header 'X-Trace-Id: update-user-001' \
  --data '{
    "username": "john.doe",
    "password": "NewPassword@123",
    "fullName": "John Doe Updated",
    "enabled": true,
    "roles": ["USER", "ADMIN"]
  }'
```

Response thanh cong:

```json
{
  "code": "00",
  "message": "User updated successfully",
  "data": {
    "id": 2,
    "username": "john.doe",
    "fullName": "John Doe Updated",
    "enabled": true,
    "roles": [
      "ADMIN",
      "USER"
    ],
    "createdAt": "2026-04-06T09:10:00Z",
    "updatedAt": "2026-04-06T09:15:00Z"
  },
  "traceId": "update-user-001",
  "timestamp": "2026-04-06T09:15:00Z"
}
```

### 3.5 Delete user

- Method: `DELETE`
- URL: `http://localhost:8080/api/v1/users/{id}`
- Auth: `Bearer token` cua admin

curl:

```bash
curl --request DELETE 'http://localhost:8080/api/v1/users/2' \
  --header 'Authorization: Bearer <admin-access-token>' \
  --header 'X-Trace-Id: delete-user-001'
```

Response thanh cong:

```json
{
  "code": "00",
  "message": "User deleted successfully",
  "data": null,
  "traceId": "delete-user-001",
  "timestamp": "2026-04-06T09:20:00Z"
}
```

### 3.6 Loi auth/permission cho user CRUD

Khong gui token:

```json
{
  "errorCode": "03",
  "message": "Authentication is required",
  "traceId": "users-auth-001",
  "timestamp": "2026-04-06T09:21:00Z"
}
```

Gui token khong co role `ADMIN`:

```json
{
  "errorCode": "03",
  "message": "Access is denied",
  "traceId": "users-auth-002",
  "timestamp": "2026-04-06T09:21:05Z"
}
```

## Ma response

Theo [ResponseCode.java](/Users/trunghieu/Desktop/code/codexdemo/src/main/java/com/example/codexdemo/common/ResponseCode.java):

- `00`: thanh cong
- `01`: loi validate request
- `02`: sai thong tin dang nhap
- `03`: khong duoc phep hoac token khong hop le
- `04`: khong tim thay resource
- `05`: du lieu bi trung, vi du username da ton tai
- `99`: loi he thong

## Cac file lien quan

- Controller: [AuthController.java](/Users/trunghieu/Desktop/code/codexdemo/src/main/java/com/example/codexdemo/controller/AuthController.java)
- Controller: [UserController.java](/Users/trunghieu/Desktop/code/codexdemo/src/main/java/com/example/codexdemo/controller/UserController.java)
- Service: [AuthServiceImpl.java](/Users/trunghieu/Desktop/code/codexdemo/src/main/java/com/example/codexdemo/service/impl/AuthServiceImpl.java)
- Service: [UserServiceImpl.java](/Users/trunghieu/Desktop/code/codexdemo/src/main/java/com/example/codexdemo/service/impl/UserServiceImpl.java)
- Security config: [SecurityConfig.java](/Users/trunghieu/Desktop/code/codexdemo/src/main/java/com/example/codexdemo/config/SecurityConfig.java)
- JWT filter: [JwtAuthenticationFilter.java](/Users/trunghieu/Desktop/code/codexdemo/src/main/java/com/example/codexdemo/security/JwtAuthenticationFilter.java)
- Error handler: [GlobalExceptionHandler.java](/Users/trunghieu/Desktop/code/codexdemo/src/main/java/com/example/codexdemo/exception/GlobalExceptionHandler.java)

## Ghi chu

Hien tai source co 2 nhom API:

- Auth: `login`, `logout`
- User CRUD: `create`, `get all`, `get by id`, `update`, `delete`

Chua co endpoint `refresh-token`, `register`, `profile/me` hoac pagination/filter cho danh sach user.
