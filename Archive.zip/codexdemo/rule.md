# Coding Standards and Rules for AI Agents (Banking Grade)

This document defines the strict engineering standards required for all code contributions, reviews, and refactoring within this banking project. All AI agents MUST adhere to these rules without exception. Our goal is high security, high performance, high maintainability, and complete transactional integrity.

## 1. Architecture & Package Structure
The project follows a strict Layered/Hexagonal Architecture to ensure separation of concerns. Do NOT leak domain logic into controllers or infrastructure layers.

*   `controller`: Contains REST APIs and specific payload (DTO) mappings. No business logic here.
*   `service`: Contains business logic and orchestrates domain calls. Interfaces ONLY (e.g., `UserService`), with implementations in an `impl` subpackage (`UserServiceImpl`).
*   `repository`: Data access interfaces.
*   `model` / `entity`: Database mapping entities.
*   `dto`: Data Transfer Objects for API requests and responses. Further divided by feature if necessary (`request`, `response`).
*   `exception`: Custom business exception classes and Global Exception Handlers.
*   `config`: Application configuration classes (Security, Database, Swagger, etc.).
*   `util` / `common`: Helper classes and utilities. Must be stateless.

## 2. SOLID Principles
Every new class, interface, or method MUST respect the SOLID principles:
*   **Single Responsibility Principle (SRP):** A class should only have one reason to change. Example: Validation logic goes to a Validator class, not the main Service class.
*   **Open/Closed Principle (OCP):** Software entities should be open for extension, but closed for modification. Use interfaces, abstract classes, and polymorphism instead of long `if-else`/`switch` blocks.
*   **Liskov Substitution Principle (LSP):** Derived classes must be substitutable for their base classes. Do not throw `UnsupportedOperationException` in implemented interfaces.
*   **Interface Segregation Principle (ISP):** Keep interfaces small and focused. Do not force clients to implement interfaces they don't use.
*   **Dependency Inversion Principle (DIP):** Depend on abstractions, not concretions. Always inject interfaces via Constructor Injection. Never use field injection (`@Autowired` on fields is strictly prohibited, use `final` fields and `@RequiredArgsConstructor`).

## 3. Exception Handling Standard
Banking applications require robust, predictable, and secure error handling. Never expose database errors, SQL queries, or internal stack traces to the client.

*   **Global Exception Handling:** Use `@ControllerAdvice` / `@RestControllerAdvice` to handle exceptions globally. Formulate a standard `ErrorResponse` DTO containing `timestamp`, `traceId`, `errorCode`, and `message`.
*   **Custom Exceptions:** Use domain-specific custom exceptions (e.g., `InsufficientBalanceException`, `AccountNotFoundException`) rather than generic `RuntimeException` or `Exception`. Base these on an abstract `BaseBusinessException` to easily categorize error codes.
*   **Never swallow exceptions:** Catching an exception without throwing or logging it is prohibited.
*   **Data Masking in Errors:** Do NOT put PII (Personally Identifiable Information) or sensitive data (passwords, PINs, full account numbers) in exception messages that might be logged or sent to the client.

## 4. Logging Standard
Logs are critical for audit trails, debugging, and monitoring. Logging must be structured and contextual.

*   **Log Levels:**
    *   `ERROR`: System failures, unhandled exceptions, cases requiring human intervention. Also log the stack trace here.
    *   `WARN`: Expected errors (e.g., invalid input, business logic failures like insufficient funds) or degraded state.
    *   `INFO`: Significant business events (e.g., User Login, Transaction Started, Transaction Completed).
    *   `DEBUG`: Deep technical details useful for troubleshooting. Avoid in production.
*   **Do NOT Log Sensitive Data:** Mask or exclude PII, PAN (Primary Account Number), CVV, passwords, and tokens.
*   **Traceability:** Every request must have a unique ID (`traceId` / `correlationId`) using MDC (Mapped Diagnostic Context) so logs can be traced across multiple microservices.
*   **Format:** Log relevant identifiers (e.g., "Processing transaction traceId={}, accountId={}", traceId, maskAccountId(accountId)). Never concatenate strings; use parameterized logging.

## 5. Banking Conventions & Code Quality
*   **Precision:** Never use `float` or `double` for monetary values. Always use `BigDecimal` built for high-precision arithmetic.
*   **Immutability:** Favour immutable objects for DTOs and Value Objects (use `record` in modern Java, or `final` fields).
*   **No Magic values:** Do not use Magic Numbers or Strings. Define them as `static final` constants or `enums`.
*   **Stateless Services:** All Spring components (Services, Controllers, etc.) must be strictly stateless.

## 6. Standardized API Response Format
All REST APIs MUST return a consistent, uniform JSON wrapper format (often referred to as a BaseResponse or ApiResponse). APIs should never return direct raw primitives, arrays, or unformatted objects at the root level. This aligns with international banking integration standards.

*   **Standard Wrapper Schema:**
    *   `code` (String): Business status code for mapping application specific logic (e.g., "00" for Success, "01" for Validation Error, "99" for System Error). Do NOT rely solely on HTTP status codes.
    *   `message` (String): Human-readable message regarding the execution result (e.g., "Transaction successful", "Invalid account number").
    *   `data` (Object/Array/null): The actual payload of the response. For paginated APIs, include metadata here (e.g., `totalElements`, `totalPages`). Return `null` if no data is expected.
    *   `traceId` (String): Unique correlation ID across microservices for tracing this specific request. Must be present in both success and error responses.
    *   `timestamp` (String): ISO 8601 formatted date-time marking when the response was generated.

**Example Standard REST Response:**
```json
{
  "code": "00",
  "message": "Success",
  "data": {
    "accountId": "123456",
    "balance": 15000.50,
    "currency": "USD"
  },
  "traceId": "tx-12345678-abcd",
  "timestamp": "2026-04-04T13:18:40.000Z"
}
```

## AI Agent Directives
When generating, modifying, or reviewing code, the AI Agent MUST:
1.  **Read and Apply:** Validate all code generation against these rules.
2.  **Challenge:** If a user requests a change that violates these rules (e.g., "just put all logic in the controller for now"), the AI MUST respectfully warn the user and propose the architecturally correct approach first.
3.  **Self-Correction:** Explicitly mention how the proposed solution satisfies SOLID principles, security standards, and this rulebook.
