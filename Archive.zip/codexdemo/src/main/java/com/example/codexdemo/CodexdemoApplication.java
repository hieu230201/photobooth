package com.example.codexdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CodexdemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(CodexdemoApplication.class, args);
    }

}
