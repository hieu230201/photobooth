package com.example.codexdemo.client;

import com.example.codexdemo.dto.request.ocr.GatewayOcrAsyncRequest;
import com.example.codexdemo.dto.response.ocr.GatewayApiResponse;
import com.example.codexdemo.dto.response.ocr.GatewayLoginData;
import com.example.codexdemo.dto.response.ocr.GatewayUploadResponse;
import java.util.List;
import org.springframework.web.multipart.MultipartFile;

public interface OcrGatewayClient {

    GatewayLoginData login();

    List<GatewayUploadResponse> uploadFiles(String accessToken, List<MultipartFile> files);

    GatewayApiResponse<String> submitAsync(String accessToken, GatewayOcrAsyncRequest request);
}
