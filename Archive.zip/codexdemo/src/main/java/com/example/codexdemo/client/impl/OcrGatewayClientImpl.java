package com.example.codexdemo.client.impl;

import com.example.codexdemo.client.OcrGatewayClient;
import com.example.codexdemo.common.SecurityConstants;
import com.example.codexdemo.config.OcrGatewayProperties;
import com.example.codexdemo.dto.request.ocr.GatewayLoginRequest;
import com.example.codexdemo.dto.request.ocr.GatewayOcrAsyncRequest;
import com.example.codexdemo.dto.response.ocr.GatewayApiResponse;
import com.example.codexdemo.dto.response.ocr.GatewayLoginData;
import com.example.codexdemo.dto.response.ocr.GatewayUploadResponse;
import com.example.codexdemo.exception.IntegrationException;
import java.io.IOException;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientException;
import org.springframework.web.multipart.MultipartFile;

@Component
@RequiredArgsConstructor
public class OcrGatewayClientImpl implements OcrGatewayClient {

    private static final ParameterizedTypeReference<GatewayApiResponse<GatewayLoginData>> LOGIN_RESPONSE_TYPE =
            new ParameterizedTypeReference<>() {
            };
    private static final ParameterizedTypeReference<GatewayApiResponse<List<GatewayUploadResponse>>> UPLOAD_RESPONSE_TYPE =
            new ParameterizedTypeReference<>() {
            };
    private static final ParameterizedTypeReference<GatewayApiResponse<String>> OCR_RESPONSE_TYPE =
            new ParameterizedTypeReference<>() {
            };

    private final RestClient ocrGatewayRestClient;
    private final OcrGatewayProperties properties;

    @Override
    public GatewayLoginData login() {
        GatewayApiResponse<GatewayLoginData> response = postJson(
                properties.loginPath(),
                new GatewayLoginRequest(properties.username(), properties.password()),
                LOGIN_RESPONSE_TYPE,
                null);
        if (response.data() == null || response.data().accessToken() == null || response.data().accessToken().isBlank()) {
            throw new IntegrationException("OCR gateway login returned an invalid token");
        }
        return response.data();
    }

    @Override
    public List<GatewayUploadResponse> uploadFiles(String accessToken, List<MultipartFile> files) {
        try {
            MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
            body.add("fileType", properties.fileType());
            for (MultipartFile file : files) {
                body.add("files", new NamedByteArrayResource(file.getBytes(), file.getOriginalFilename()));
            }

            GatewayApiResponse<List<GatewayUploadResponse>> response = ocrGatewayRestClient.post()
                    .uri(properties.uploadPath())
                    .header(SecurityConstants.AUTHORIZATION_HEADER, SecurityConstants.BEARER_PREFIX + accessToken)
                    .contentType(MediaType.MULTIPART_FORM_DATA)
                    .body(body)
                    .retrieve()
                    .body(UPLOAD_RESPONSE_TYPE);
            validateGatewayResponse(response, "upload OCR files");
            return response.data();
        } catch (IOException exception) {
            throw new IntegrationException("Unable to read upload file content");
        } catch (RestClientException exception) {
            throw new IntegrationException("OCR gateway upload request failed", exception);
        }
    }

    @Override
    public GatewayApiResponse<String> submitAsync(String accessToken, GatewayOcrAsyncRequest request) {
        GatewayApiResponse<String> response = postJson(
                properties.asyncOcrPath(),
                request,
                OCR_RESPONSE_TYPE,
                accessToken);
        if (response.data() == null || response.data().isBlank()) {
            throw new IntegrationException("OCR gateway async response did not contain refNo");
        }
        return response;
    }

    private <T> GatewayApiResponse<T> postJson(String path,
                                               Object payload,
                                               ParameterizedTypeReference<GatewayApiResponse<T>> responseType,
                                               String accessToken) {
        try {
            RestClient.RequestBodySpec request = ocrGatewayRestClient.post()
                    .uri(path)
                    .contentType(MediaType.APPLICATION_JSON);
            if (accessToken != null && !accessToken.isBlank()) {
                request.header(SecurityConstants.AUTHORIZATION_HEADER, SecurityConstants.BEARER_PREFIX + accessToken);
            }

            GatewayApiResponse<T> response = request.body(payload)
                    .retrieve()
                    .body(responseType);
            validateGatewayResponse(response, path);
            return response;
        } catch (RestClientException exception) {
            throw new IntegrationException("OCR gateway request failed for path: " + path, exception);
        }
    }

    private void validateGatewayResponse(GatewayApiResponse<?> response, String action) {
        if (response == null) {
            throw new IntegrationException("OCR gateway returned an empty response for " + action);
        }
        if (response.status() == null || response.status() != 200) {
            throw new IntegrationException("OCR gateway returned non-success status for " + action);
        }
    }

    private static final class NamedByteArrayResource extends ByteArrayResource {

        private final String filename;

        private NamedByteArrayResource(byte[] byteArray, String filename) {
            super(byteArray);
            this.filename = filename;
        }

        @Override
        public String getFilename() {
            return filename;
        }
    }
}
