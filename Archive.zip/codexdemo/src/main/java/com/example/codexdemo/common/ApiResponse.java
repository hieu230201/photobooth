package com.example.codexdemo.common;

import java.time.OffsetDateTime;

public record ApiResponse<T>(
        String code,
        String message,
        T data,
        String traceId,
        OffsetDateTime timestamp
) {

    public static <T> ApiResponse<T> success(String code, String message, T data, String traceId) {
        return new ApiResponse<>(code, message, data, traceId, OffsetDateTime.now());
    }
}
