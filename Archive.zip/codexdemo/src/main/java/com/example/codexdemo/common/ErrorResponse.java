package com.example.codexdemo.common;

import java.time.OffsetDateTime;

public record ErrorResponse(
        String errorCode,
        String message,
        String traceId,
        OffsetDateTime timestamp
) {

    public static ErrorResponse of(String errorCode, String message, String traceId) {
        return new ErrorResponse(errorCode, message, traceId, OffsetDateTime.now());
    }
}
