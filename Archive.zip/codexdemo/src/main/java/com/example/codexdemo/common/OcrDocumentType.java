package com.example.codexdemo.common;

import com.example.codexdemo.exception.ValidationException;
import java.util.Arrays;

public enum OcrDocumentType {

    DN_CHUYENVON("dn_chuyenvon", "PHIEU_DE_NGHI_DIEU_CHUYEN_VON"),
    LENH_CHUYENVON("lenh_chuyenvon", "LENH_DIEU_CHUYEN_VON"),
    PHIEU_XK_MAU("phieu_xk_mau", "PHIEU_XUAT_KHO_TIENVANG"),
    PHIEU_NK_MAU("phieu_nk_mau", "LENH_DIEU_CHUYEN_TIEN_VE"),
    BBPC_TTQ("bbpc_ttq", "BB_PHAN_CONG_TO_TIEP_QUY"),
    DN_UNGTIEN("dn_ungtien", "GIAY_DN_UNG_TIEN_MAT"),
    BIENLAI_LB("bienlai_lb", "BIEN_LAI_IN_LB"),
    BBNT_LB("bbnt_lb", "BB_NAP_TIEN_LB"),
    LENH_DIEUCHUYEN("lenh_dieuchuyen", "LENH_DIEU_CHUYEN_TIEN"),
    BBKQ_TIENMAT("bbkq_tienmat", "BB_KIEM_QUY_TIEN_MAT"),
    BIENLAI_LB_FINAL("bienlai_lb_final", "BIEN_LAI_IN_LB_FINAL"),
    SK_TIENMAT_LB("sk_tienmat_lb", "SAO_KE_TAI_KHOAN_TIEN_MAT_LB"),
    LENH_DIEUCHUYEN_VE("lenh_dieuchuyen_ve", "LENH_DIEU_CHUYEN_TIEN_VE");

    private final String code;
    private final String callbackDocumentType;

    OcrDocumentType(String code, String callbackDocumentType) {
        this.code = code;
        this.callbackDocumentType = callbackDocumentType;
    }

    public String code() {
        return code;
    }

    public String callbackDocumentType() {
        return callbackDocumentType;
    }

    public static OcrDocumentType fromCode(String value) {
        return Arrays.stream(values())
                .filter(type -> type.code.equals(value == null ? null : value.trim()))
                .findFirst()
                .orElseThrow(() -> new ValidationException("Unsupported OCR document type"));
    }
}
