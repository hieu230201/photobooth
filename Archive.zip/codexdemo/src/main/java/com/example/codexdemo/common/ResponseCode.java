package com.example.codexdemo.common;

public final class ResponseCode {

    public static final String SUCCESS = "00";
    public static final String VALIDATION_ERROR = "01";
    public static final String AUTHENTICATION_FAILED = "02";
    public static final String UNAUTHORIZED = "03";
    public static final String RESOURCE_NOT_FOUND = "04";
    public static final String CONFLICT = "05";
    public static final String INTEGRATION_ERROR = "96";
    public static final String SYSTEM_ERROR = "99";

    private ResponseCode() {
    }
}
