package com.example.codexdemo.common;

public final class SecurityConstants {

    public static final String TRACE_ID = "traceId";
    public static final String TRACE_ID_HEADER = "X-Trace-Id";
    public static final String KSS_HEADER = "X-KSS-Header";
    public static final String KSS_HEADER_VALUE = "422b5ed8-50c8-4077-a67e-a5227f6e0260";
    public static final String AUTHORIZATION_HEADER = "Authorization";
    public static final String BEARER_PREFIX = "Bearer ";
    public static final String TOKEN_TYPE = "Bearer";

    private SecurityConstants() {
    }
}
