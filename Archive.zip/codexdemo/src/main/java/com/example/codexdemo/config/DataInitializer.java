package com.example.codexdemo.config;

import com.example.codexdemo.entity.RoleEntity;
import com.example.codexdemo.entity.RoleName;
import com.example.codexdemo.entity.UserEntity;
import com.example.codexdemo.repository.RevokedTokenRepository;
import com.example.codexdemo.repository.RoleRepository;
import com.example.codexdemo.repository.UserRepository;
import java.time.OffsetDateTime;
import java.util.Set;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

@Slf4j
@Configuration
@RequiredArgsConstructor
public class DataInitializer {

    private static final String DEFAULT_ADMIN_USERNAME = "admin";
    private static final String DEFAULT_ADMIN_PASSWORD = "Admin@123";
    private static final String DEFAULT_ADMIN_FULL_NAME = "System Administrator";

    private final RoleRepository roleRepository;
    private final UserRepository userRepository;
    private final RevokedTokenRepository revokedTokenRepository;
    private final PasswordEncoder passwordEncoder;

    @Bean
    public CommandLineRunner bootstrapSecurityData() {
        return args -> {
            RoleEntity adminRole = roleRepository.findByName(RoleName.ADMIN)
                    .orElseGet(() -> roleRepository.save(new RoleEntity(RoleName.ADMIN)));
            RoleEntity userRole = roleRepository.findByName(RoleName.USER)
                    .orElseGet(() -> roleRepository.save(new RoleEntity(RoleName.USER)));

            userRepository.findByUsername(DEFAULT_ADMIN_USERNAME)
                    .orElseGet(() -> userRepository.save(new UserEntity(
                            DEFAULT_ADMIN_USERNAME,
                            passwordEncoder.encode(DEFAULT_ADMIN_PASSWORD),
                            DEFAULT_ADMIN_FULL_NAME,
                            true,
                            Set.of(adminRole, userRole)
                    )));

            revokedTokenRepository.deleteByExpiresAtBefore(OffsetDateTime.now());
            log.info("Security bootstrap completed");
        };
    }
}
