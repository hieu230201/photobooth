package com.example.codexdemo.config;

import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestClient;

@Configuration
@EnableConfigurationProperties(OcrGatewayProperties.class)
public class OcrGatewayConfig {

    @Bean
    public RestClient.Builder restClientBuilder() {
        return RestClient.builder();
    }

    @Bean
    public RestClient ocrGatewayRestClient(RestClient.Builder builder, OcrGatewayProperties properties) {
        return builder.baseUrl(properties.baseUrl()).build();
    }
}
