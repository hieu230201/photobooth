package com.example.codexdemo.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "integration.ocr.gateway")
public record OcrGatewayProperties(
        String baseUrl,
        String loginPath,
        String uploadPath,
        String asyncOcrPath,
        String fileType,
        String username,
        String password,
        String callbackUser,
        String callbackPassword
) {
}
