package com.example.codexdemo.controller;

import com.example.codexdemo.common.ApiResponse;
import com.example.codexdemo.common.ResponseCode;
import com.example.codexdemo.common.SecurityConstants;
import com.example.codexdemo.dto.request.LoginRequest;
import com.example.codexdemo.dto.response.LoginResponse;
import com.example.codexdemo.dto.response.LogoutResponse;
import com.example.codexdemo.service.AuthService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.slf4j.MDC;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;

    @PostMapping("/login")
    public ApiResponse<LoginResponse> login(@Valid @RequestBody LoginRequest request) {
        return ApiResponse.success(ResponseCode.SUCCESS, "Login successful", authService.login(request), currentTraceId());
    }

    @PostMapping("/logout")
    public ApiResponse<LogoutResponse> logout(
            @RequestHeader(name = SecurityConstants.AUTHORIZATION_HEADER, required = false) String authorizationHeader,
            HttpServletRequest request) {
        String accessToken = resolveToken(authorizationHeader, request);
        return ApiResponse.success(ResponseCode.SUCCESS, "Logout successful", authService.logout(accessToken), currentTraceId());
    }

    private String resolveToken(String authorizationHeader, HttpServletRequest request) {
        if (authorizationHeader != null && authorizationHeader.startsWith(SecurityConstants.BEARER_PREFIX)) {
            return authorizationHeader.substring(SecurityConstants.BEARER_PREFIX.length());
        }
        Object token = request.getAttribute("accessToken");
        return token == null ? null : token.toString();
    }

    private String currentTraceId() {
        return MDC.get(SecurityConstants.TRACE_ID);
    }
}
