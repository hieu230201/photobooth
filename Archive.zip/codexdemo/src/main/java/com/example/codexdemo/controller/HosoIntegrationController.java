package com.example.codexdemo.controller;

import com.example.codexdemo.common.ApiResponse;
import com.example.codexdemo.common.ResponseCode;
import com.example.codexdemo.common.SecurityConstants;
import com.example.codexdemo.dto.request.hoso.HosoAtkqSaveRequest;
import com.example.codexdemo.dto.request.hoso.HosoPdttSaveRequest;
import com.example.codexdemo.exception.UnauthorizedException;
import com.example.codexdemo.service.HosoIntegrationService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.slf4j.MDC;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/hoso-integration/save")
@RequiredArgsConstructor
public class HosoIntegrationController {

    private final HosoIntegrationService hosoIntegrationService;

    @PostMapping("/hoso-pdtt")
    public ApiResponse<Boolean> savePdtt(
            @RequestHeader(name = SecurityConstants.KSS_HEADER, required = false) String kssHeader,
            @Valid @RequestBody HosoPdttSaveRequest request) {
        validateKssHeader(kssHeader);
        return ApiResponse.success(ResponseCode.SUCCESS, "OK", hosoIntegrationService.savePdtt(request), currentTraceId());
    }

    @PostMapping("/hoso-atkq")
    public ApiResponse<Boolean> saveAtkq(
            @RequestHeader(name = SecurityConstants.KSS_HEADER, required = false) String kssHeader,
            @Valid @RequestBody HosoAtkqSaveRequest request) {
        validateKssHeader(kssHeader);
        return ApiResponse.success(ResponseCode.SUCCESS, "OK", hosoIntegrationService.saveAtkq(request), currentTraceId());
    }

    private void validateKssHeader(String kssHeader) {
        if (!SecurityConstants.KSS_HEADER_VALUE.equals(kssHeader)) {
            throw new UnauthorizedException("Invalid X-KSS-Header");
        }
    }

    private String currentTraceId() {
        return MDC.get(SecurityConstants.TRACE_ID);
    }
}
