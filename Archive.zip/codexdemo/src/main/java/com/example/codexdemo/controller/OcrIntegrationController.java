package com.example.codexdemo.controller;

import com.example.codexdemo.common.ApiResponse;
import com.example.codexdemo.common.ResponseCode;
import com.example.codexdemo.common.SecurityConstants;
import com.example.codexdemo.dto.request.ocr.OcrAsyncFlowRequest;
import com.example.codexdemo.dto.request.ocr.OcrCallbackRequest;
import com.example.codexdemo.dto.response.ocr.OcrAsyncFlowResponse;
import com.example.codexdemo.dto.response.ocr.OcrCallbackAckResponse;
import com.example.codexdemo.service.OcrCallbackService;
import com.example.codexdemo.service.OcrFlowService;
import jakarta.validation.Valid;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.slf4j.MDC;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequiredArgsConstructor
public class OcrIntegrationController {

    private final OcrFlowService ocrFlowService;
    private final OcrCallbackService ocrCallbackService;

    @PostMapping(value = "/api/v1/ocr/kss/async", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ApiResponse<OcrAsyncFlowResponse> submitAsyncFlow(@RequestPart("files") List<MultipartFile> files,
                                                             @RequestParam("refNo") String refNo,
                                                             @RequestParam("type") String type) {
        OcrAsyncFlowRequest request = new OcrAsyncFlowRequest(files, refNo, type);
        return ApiResponse.success(
                ResponseCode.SUCCESS,
                "OCR asynchronous flow submitted successfully",
                ocrFlowService.submitAsyncFlow(request),
                currentTraceId());
    }

    @PostMapping(value = "/SaveResponseGenAI", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse<OcrCallbackAckResponse> receiveCallback(
            @RequestHeader(name = "user", required = false) String user,
            @RequestHeader(name = "Transactionsid", required = false) String transactionId,
            @RequestHeader(name = "Password", required = false) String password,
            @Valid @RequestBody OcrCallbackRequest request) {
        return ApiResponse.success(
                ResponseCode.SUCCESS,
                "OCR callback received successfully",
                ocrCallbackService.processCallback(user, transactionId, password, request),
                currentTraceId());
    }

    private String currentTraceId() {
        return MDC.get(SecurityConstants.TRACE_ID);
    }
}
