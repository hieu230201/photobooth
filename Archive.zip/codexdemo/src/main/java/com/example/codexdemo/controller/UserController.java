package com.example.codexdemo.controller;

import com.example.codexdemo.common.ApiResponse;
import com.example.codexdemo.common.ResponseCode;
import com.example.codexdemo.common.SecurityConstants;
import com.example.codexdemo.dto.request.CreateUserRequest;
import com.example.codexdemo.dto.request.UpdateUserRequest;
import com.example.codexdemo.dto.response.UserResponse;
import com.example.codexdemo.service.UserService;
import jakarta.validation.Valid;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.slf4j.MDC;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/users")
@RequiredArgsConstructor
@PreAuthorize("hasRole('ADMIN')")
public class UserController {

    private final UserService userService;

    @PostMapping
    public ApiResponse<UserResponse> createUser(@Valid @RequestBody CreateUserRequest request) {
        return ApiResponse.success(ResponseCode.SUCCESS, "User created successfully", userService.createUser(request), currentTraceId());
    }

    @GetMapping
    public ApiResponse<List<UserResponse>> getUsers() {
        return ApiResponse.success(ResponseCode.SUCCESS, "Users fetched successfully", userService.getUsers(), currentTraceId());
    }

    @GetMapping("/{id}")
    public ApiResponse<UserResponse> getUserById(@PathVariable Long id) {
        return ApiResponse.success(ResponseCode.SUCCESS, "User fetched successfully", userService.getUserById(id), currentTraceId());
    }

    @PutMapping("/{id}")
    public ApiResponse<UserResponse> updateUser(@PathVariable Long id, @Valid @RequestBody UpdateUserRequest request) {
        return ApiResponse.success(ResponseCode.SUCCESS, "User updated successfully", userService.updateUser(id, request), currentTraceId());
    }

    @DeleteMapping("/{id}")
    public ApiResponse<Void> deleteUser(@PathVariable Long id) {
        userService.deleteUser(id);
        return ApiResponse.success(ResponseCode.SUCCESS, "User deleted successfully", null, currentTraceId());
    }

    private String currentTraceId() {
        return MDC.get(SecurityConstants.TRACE_ID);
    }
}
