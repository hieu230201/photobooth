package com.example.codexdemo.dto.request;

import com.example.codexdemo.entity.RoleName;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import java.util.Set;

public record CreateUserRequest(
        @NotBlank(message = "username must not be blank")
        @Size(max = 50, message = "username must be at most 50 characters")
        String username,
        @NotBlank(message = "password must not be blank")
        @Size(min = 8, max = 100, message = "password must be between 8 and 100 characters")
        String password,
        @NotBlank(message = "fullName must not be blank")
        @Size(max = 100, message = "fullName must be at most 100 characters")
        String fullName,
        boolean enabled,
        @NotEmpty(message = "roles must not be empty")
        Set<RoleName> roles
) {
}
