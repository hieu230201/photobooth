package com.example.codexdemo.dto.request.hoso;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import java.util.List;

public record AtkqDoiChieuRequest(
        @NotBlank(message = "datadoichieu must not be blank")
        String datadoichieu,
        String ngaydieuchuyen,
        String donvigiao,
        String donvinhan,
        @Valid
        List<AtkqMoneyInfoRequest> thongtindieuchuyen,
        @Valid
        List<AtkqVaultExportInfoRequest> thongtinxuatkho,
        String ngaytiepquy,
        String hotennaptien1,
        String hotennaptien2,
        String hotenks,
        List<String> thanhviennhomtiepquy,
        String tenmaytiepquy,
        String mamaytiepquy,
        String sotientiepquy,
        List<String> soseri,
        String ngaykiemquy,
        String tenmaykiemquy,
        String mamaykiemquy,
        String sotienkiemquy,
        String sotaikhoanmay,
        String chenhlech,
        String hotenkiemquy1,
        String hotenkiemquy2
) {
}
