package com.example.codexdemo.dto.request.hoso;

public record AtkqMoneyInfoRequest(
        String sotiendieuchuyen,
        String loaitien
) {
}
