package com.example.codexdemo.dto.request.hoso;

import jakarta.validation.constraints.NotBlank;

public record AtkqReferenceRequest(
        @NotBlank(message = "refFcc must not be blank")
        String refFcc,
        String tenChiNhanh,
        String maChiNhanh
) {
}
