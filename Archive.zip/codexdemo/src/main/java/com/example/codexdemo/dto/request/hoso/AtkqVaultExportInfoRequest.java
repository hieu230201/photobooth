package com.example.codexdemo.dto.request.hoso;

public record AtkqVaultExportInfoRequest(
        String sotienxuatkho,
        String loaitienxuatkho,
        String sotiennopvuot,
        String loaitiennopvuot
) {
}
