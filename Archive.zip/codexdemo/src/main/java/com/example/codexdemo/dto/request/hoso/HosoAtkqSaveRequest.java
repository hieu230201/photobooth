package com.example.codexdemo.dto.request.hoso;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import java.util.List;

public record HosoAtkqSaveRequest(
        @NotBlank(message = "loaiYeuCau must not be blank")
        String loaiYeuCau,
        @NotBlank(message = "path must not be blank")
        String path,
        @NotBlank(message = "maYeuCau must not be blank")
        String maYeuCau,
        @Valid
        @NotEmpty(message = "data must not be empty")
        List<AtkqReferenceRequest> data,
        @Valid
        @NotNull(message = "datadoichieu must not be null")
        AtkqDoiChieuRequest datadoichieu
) {
}
