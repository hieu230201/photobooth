package com.example.codexdemo.dto.request.hoso;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import java.util.List;

public record HosoPdttSaveRequest(
        @NotBlank(message = "loaiNghiepVu must not be blank")
        String loaiNghiepVu,
        @NotBlank(message = "requestID must not be blank")
        String requestID,
        @NotEmpty(message = "ref must not be empty")
        List<@NotBlank(message = "ref item must not be blank") String> ref,
        @NotBlank(message = "file must not be blank")
        String file,
        @NotBlank(message = "maChiNhanh must not be blank")
        String maChiNhanh,
        @NotBlank(message = "ngayChungTu must not be blank")
        String ngayChungTu,
        @NotBlank(message = "kySo must not be blank")
        String kySo
) {
}
