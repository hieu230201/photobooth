package com.example.codexdemo.dto.request.ocr;

public record GatewayLoginRequest(
        String user,
        String password
) {
}
