package com.example.codexdemo.dto.request.ocr;

public record GatewayOcrAsyncRequest(
        String fileId,
        String refNo,
        String type
) {
}
