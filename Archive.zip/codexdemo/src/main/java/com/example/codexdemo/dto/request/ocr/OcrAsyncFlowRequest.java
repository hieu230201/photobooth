package com.example.codexdemo.dto.request.ocr;

import java.util.List;
import org.springframework.web.multipart.MultipartFile;

public record OcrAsyncFlowRequest(
        List<MultipartFile> files,
        String refNo,
        String type
) {
}
