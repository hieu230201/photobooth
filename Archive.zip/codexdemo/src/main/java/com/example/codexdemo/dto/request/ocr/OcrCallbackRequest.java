package com.example.codexdemo.dto.request.ocr;

import com.fasterxml.jackson.annotation.JsonAnySetter;
import jakarta.validation.constraints.NotBlank;
import java.util.LinkedHashMap;
import java.util.Map;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
public class OcrCallbackRequest {

    @NotBlank(message = "status must not be blank")
    private String status;

    @NotBlank(message = "message must not be blank")
    private String message;

    @NotBlank(message = "refNo must not be blank")
    private String refNo;

    @NotBlank(message = "documentType must not be blank")
    private String documentType;

    private final Map<String, Object> payload = new LinkedHashMap<>();

    @JsonAnySetter
    void addPayload(String key, Object value) {
        if (!"status".equals(key) && !"message".equals(key) && !"refNo".equals(key) && !"documentType".equals(key)) {
            payload.put(key, value);
        }
    }
}
