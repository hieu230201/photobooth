package com.example.codexdemo.dto.response;

import java.time.OffsetDateTime;

public record LoginResponse(
        String accessToken,
        String tokenType,
        String issuer,
        String subject,
        String jwtId,
        OffsetDateTime issuedAt,
        OffsetDateTime expiresAt,
        UserProfileResponse user
) {
}
