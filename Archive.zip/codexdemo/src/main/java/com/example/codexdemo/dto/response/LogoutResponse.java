package com.example.codexdemo.dto.response;

public record LogoutResponse(
        String status
) {
}
