package com.example.codexdemo.dto.response;

import java.util.Set;

public record UserProfileResponse(
        Long id,
        String username,
        String fullName,
        Set<String> roles
) {
}
