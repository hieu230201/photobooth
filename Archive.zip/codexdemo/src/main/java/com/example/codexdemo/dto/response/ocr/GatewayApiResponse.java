package com.example.codexdemo.dto.response.ocr;

public record GatewayApiResponse<T>(
        String uuid,
        Integer status,
        String message,
        String time,
        T data
) {
}
