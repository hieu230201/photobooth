package com.example.codexdemo.dto.response.ocr;

public record GatewayLoginData(
        String accessToken,
        String refreshToken,
        String tokenType
) {
}
