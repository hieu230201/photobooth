package com.example.codexdemo.dto.response.ocr;

public record GatewayUploadResponse(
        String fileId,
        String sourceFileName,
        String idMinio
) {
}
