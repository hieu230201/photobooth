package com.example.codexdemo.dto.response.ocr;

import java.util.List;

public record OcrAsyncFlowResponse(
        String refNo,
        String type,
        List<OcrSubmissionResponse> submissions
) {
}
