package com.example.codexdemo.dto.response.ocr;

public record OcrCallbackAckResponse(
        String transactionId,
        String refNo,
        String documentType,
        String callbackStatus
) {
}
