package com.example.codexdemo.dto.response.ocr;

public record OcrSubmissionResponse(
        String requestId,
        String refNo,
        String fileId,
        String sourceFileName,
        String callbackDocumentType
) {
}
