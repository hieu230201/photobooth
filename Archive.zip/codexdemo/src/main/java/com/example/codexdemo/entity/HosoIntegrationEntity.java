package com.example.codexdemo.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.Table;
import java.time.OffsetDateTime;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

@Getter
@Entity
@NoArgsConstructor
@Table(name = "hoso_integrations")
public class HosoIntegrationEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private HosoSourceType sourceType;

    @Column(nullable = false, length = 100)
    private String businessType;

    @Column(length = 100)
    private String externalRequestId;

    @Column(length = 100)
    private String referenceKey;

    @Column(length = 255)
    private String fileLocation;

    @Column(length = 50)
    private String branchCode;

    @Column(length = 50)
    private String signStatus;

    @Lob
    @Column(nullable = false)
    private String normalizedPayload;

    @Lob
    @Column(nullable = false)
    private String rawPayload;

    @CreationTimestamp
    @Column(nullable = false, updatable = false)
    private OffsetDateTime createdAt;

    public HosoIntegrationEntity(HosoSourceType sourceType,
                                 String businessType,
                                 String externalRequestId,
                                 String referenceKey,
                                 String fileLocation,
                                 String branchCode,
                                 String signStatus,
                                 String normalizedPayload,
                                 String rawPayload) {
        this.sourceType = sourceType;
        this.businessType = businessType;
        this.externalRequestId = externalRequestId;
        this.referenceKey = referenceKey;
        this.fileLocation = fileLocation;
        this.branchCode = branchCode;
        this.signStatus = signStatus;
        this.normalizedPayload = normalizedPayload;
        this.rawPayload = rawPayload;
    }
}
