package com.example.codexdemo.entity;

public enum HosoSourceType {
    PDTT,
    ATKQ
}
