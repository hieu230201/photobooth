package com.example.codexdemo.entity;

public enum RoleName {
    ADMIN,
    USER
}
