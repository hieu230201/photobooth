package com.example.codexdemo.exception;

import com.example.codexdemo.common.ResponseCode;
import org.springframework.http.HttpStatus;

public class AuthenticationFailedException extends BaseBusinessException {

    public AuthenticationFailedException(String message) {
        super(ResponseCode.AUTHENTICATION_FAILED, message, HttpStatus.UNAUTHORIZED);
    }
}
