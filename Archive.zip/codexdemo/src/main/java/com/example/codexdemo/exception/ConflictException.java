package com.example.codexdemo.exception;

import com.example.codexdemo.common.ResponseCode;
import org.springframework.http.HttpStatus;

public class ConflictException extends BaseBusinessException {

    public ConflictException(String message) {
        super(ResponseCode.CONFLICT, message, HttpStatus.CONFLICT);
    }
}
