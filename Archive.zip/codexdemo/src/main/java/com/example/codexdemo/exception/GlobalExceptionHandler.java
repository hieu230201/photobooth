package com.example.codexdemo.exception;

import com.example.codexdemo.common.ErrorResponse;
import com.example.codexdemo.common.ResponseCode;
import com.example.codexdemo.common.SecurityConstants;
import jakarta.servlet.http.HttpServletRequest;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authorization.AuthorizationDeniedException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@Slf4j
@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(BaseBusinessException.class)
    public ResponseEntity<ErrorResponse> handleBusinessException(BaseBusinessException exception, HttpServletRequest request) {
        String traceId = resolveTraceId();
        log.warn("Business error traceId={}, path={}, code={}, message={}",
                traceId, request.getRequestURI(), exception.getErrorCode(), exception.getMessage());
        return ResponseEntity.status(exception.getHttpStatus())
                .body(ErrorResponse.of(exception.getErrorCode(), exception.getMessage(), traceId));
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ErrorResponse> handleValidationException(MethodArgumentNotValidException exception,
                                                                   HttpServletRequest request) {
        String traceId = resolveTraceId();
        String message = exception.getBindingResult()
                .getFieldErrors()
                .stream()
                .map(FieldError::getDefaultMessage)
                .collect(Collectors.joining("; "));
        log.warn("Validation error traceId={}, path={}, message={}", traceId, request.getRequestURI(), message);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(ErrorResponse.of(ResponseCode.VALIDATION_ERROR, message, traceId));
    }

    @ExceptionHandler(AuthorizationDeniedException.class)
    public ResponseEntity<ErrorResponse> handleAuthorizationDeniedException(AuthorizationDeniedException exception,
                                                                           HttpServletRequest request) {
        String traceId = resolveTraceId();
        log.warn("Authorization denied traceId={}, path={}, message={}",
                traceId, request.getRequestURI(), exception.getMessage());
        return ResponseEntity.status(HttpStatus.FORBIDDEN)
                .body(ErrorResponse.of(ResponseCode.UNAUTHORIZED, "Access is denied", traceId));
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleUnexpectedException(Exception exception, HttpServletRequest request) {
        String traceId = resolveTraceId();
        log.error("Unhandled error traceId={}, path={}", traceId, request.getRequestURI(), exception);
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(ErrorResponse.of(ResponseCode.SYSTEM_ERROR, "Internal server error", traceId));
    }

    private String resolveTraceId() {
        return MDC.get(SecurityConstants.TRACE_ID);
    }
}
