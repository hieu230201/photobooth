package com.example.codexdemo.exception;

import com.example.codexdemo.common.ResponseCode;
import org.springframework.http.HttpStatus;

public class IntegrationException extends BaseBusinessException {

    public IntegrationException(String message) {
        super(ResponseCode.INTEGRATION_ERROR, message, HttpStatus.BAD_GATEWAY);
    }

    public IntegrationException(String message, Throwable cause) {
        super(ResponseCode.INTEGRATION_ERROR, message, HttpStatus.BAD_GATEWAY);
        initCause(cause);
    }
}
