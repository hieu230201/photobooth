package com.example.codexdemo.exception;

import com.example.codexdemo.common.ResponseCode;
import org.springframework.http.HttpStatus;

public class ResourceNotFoundException extends BaseBusinessException {

    public ResourceNotFoundException(String message) {
        super(ResponseCode.RESOURCE_NOT_FOUND, message, HttpStatus.NOT_FOUND);
    }
}
