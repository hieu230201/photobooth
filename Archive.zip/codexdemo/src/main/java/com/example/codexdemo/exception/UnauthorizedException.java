package com.example.codexdemo.exception;

import com.example.codexdemo.common.ResponseCode;
import org.springframework.http.HttpStatus;

public class UnauthorizedException extends BaseBusinessException {

    public UnauthorizedException(String message) {
        super(ResponseCode.UNAUTHORIZED, message, HttpStatus.UNAUTHORIZED);
    }
}
