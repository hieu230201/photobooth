package com.example.codexdemo.exception;

import com.example.codexdemo.common.ResponseCode;
import org.springframework.http.HttpStatus;

public class ValidationException extends BaseBusinessException {

    public ValidationException(String message) {
        super(ResponseCode.VALIDATION_ERROR, message, HttpStatus.BAD_REQUEST);
    }
}
