package com.example.codexdemo.repository;

import com.example.codexdemo.entity.HosoIntegrationEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HosoIntegrationRepository extends JpaRepository<HosoIntegrationEntity, Long> {
}
