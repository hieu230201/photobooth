package com.example.codexdemo.repository;

import com.example.codexdemo.entity.RevokedTokenEntity;
import java.time.OffsetDateTime;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RevokedTokenRepository extends JpaRepository<RevokedTokenEntity, Long> {

    boolean existsByJti(String jti);

    void deleteByExpiresAtBefore(OffsetDateTime cutoff);
}
