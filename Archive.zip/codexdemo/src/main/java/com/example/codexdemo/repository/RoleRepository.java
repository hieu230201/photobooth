package com.example.codexdemo.repository;

import com.example.codexdemo.entity.RoleEntity;
import com.example.codexdemo.entity.RoleName;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository extends JpaRepository<RoleEntity, Long> {

    Optional<RoleEntity> findByName(RoleName name);
}
