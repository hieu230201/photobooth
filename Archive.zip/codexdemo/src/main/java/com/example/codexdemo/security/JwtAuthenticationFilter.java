package com.example.codexdemo.security;

import com.example.codexdemo.common.SecurityConstants;
import com.example.codexdemo.entity.UserEntity;
import com.example.codexdemo.repository.RevokedTokenRepository;
import com.example.codexdemo.repository.UserRepository;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

@Slf4j
@Component
@RequiredArgsConstructor
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    private final JwtService jwtService;
    private final UserRepository userRepository;
    private final RevokedTokenRepository revokedTokenRepository;

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain) throws ServletException, IOException {
        String authorization = request.getHeader(SecurityConstants.AUTHORIZATION_HEADER);
        if (authorization == null || !authorization.startsWith(SecurityConstants.BEARER_PREFIX)) {
            filterChain.doFilter(request, response);
            return;
        }

        String token = authorization.substring(SecurityConstants.BEARER_PREFIX.length());
        try {
            Claims claims = jwtService.parseToken(token);
            if (revokedTokenRepository.existsByJti(claims.getId())) {
                filterChain.doFilter(request, response);
                return;
            }

            String username = claims.getSubject();
            UserEntity user = userRepository.findByUsername(username).orElse(null);
            if (user != null && SecurityContextHolder.getContext().getAuthentication() == null) {
                CustomUserDetails userDetails = new CustomUserDetails(user);
                UsernamePasswordAuthenticationToken authenticationToken =
                        new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());
                authenticationToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                SecurityContextHolder.getContext().setAuthentication(authenticationToken);
                request.setAttribute("accessToken", token);
            }
        } catch (JwtException exception) {
            log.warn("Invalid JWT traceId={}, path={}", MDC.get(SecurityConstants.TRACE_ID), request.getRequestURI());
        }
        filterChain.doFilter(request, response);
    }
}
