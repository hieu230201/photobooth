package com.example.codexdemo.security;

import com.example.codexdemo.entity.UserEntity;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Date;
import java.util.Map;
import java.util.UUID;
import javax.crypto.SecretKey;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class JwtService {

    private final JwtProperties jwtProperties;

    public TokenDetails generateAccessToken(UserEntity user) {
        OffsetDateTime issuedAt = OffsetDateTime.now(ZoneOffset.UTC);
        OffsetDateTime expiresAt = issuedAt.plusSeconds(jwtProperties.getAccessTokenTtlSeconds());
        String jwtId = UUID.randomUUID().toString();
        String token = Jwts.builder()
                .issuer(jwtProperties.getIssuer())
                .subject(user.getUsername())
                .id(jwtId)
                .issuedAt(Date.from(issuedAt.toInstant()))
                .expiration(Date.from(expiresAt.toInstant()))
                .claims(Map.of("roles", user.getRoles().stream().map(role -> role.getName().name()).toList()))
                .signWith(getSigningKey(), Jwts.SIG.HS256)
                .compact();
        return new TokenDetails(token, jwtId, jwtProperties.getIssuer(), user.getUsername(), issuedAt, expiresAt);
    }

    public Claims parseToken(String token) {
        return Jwts.parser()
                .verifyWith(getSigningKey())
                .build()
                .parseSignedClaims(token)
                .getPayload();
    }

    private SecretKey getSigningKey() {
        return Keys.hmacShaKeyFor(java.util.Base64.getDecoder().decode(jwtProperties.getSecret()));
    }

    public record TokenDetails(
            String token,
            String jwtId,
            String issuer,
            String subject,
            OffsetDateTime issuedAt,
            OffsetDateTime expiresAt
    ) {
    }
}
