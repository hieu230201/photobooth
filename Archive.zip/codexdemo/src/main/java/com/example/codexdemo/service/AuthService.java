package com.example.codexdemo.service;

import com.example.codexdemo.dto.request.LoginRequest;
import com.example.codexdemo.dto.response.LoginResponse;
import com.example.codexdemo.dto.response.LogoutResponse;

public interface AuthService {

    LoginResponse login(LoginRequest request);

    LogoutResponse logout(String accessToken);
}
