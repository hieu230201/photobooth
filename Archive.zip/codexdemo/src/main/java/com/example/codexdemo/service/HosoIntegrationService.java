package com.example.codexdemo.service;

import com.example.codexdemo.dto.request.hoso.HosoAtkqSaveRequest;
import com.example.codexdemo.dto.request.hoso.HosoPdttSaveRequest;

public interface HosoIntegrationService {

    boolean savePdtt(HosoPdttSaveRequest request);

    boolean saveAtkq(HosoAtkqSaveRequest request);
}
