package com.example.codexdemo.service;

import com.example.codexdemo.dto.request.ocr.OcrCallbackRequest;
import com.example.codexdemo.dto.response.ocr.OcrCallbackAckResponse;

public interface OcrCallbackService {

    OcrCallbackAckResponse processCallback(String user, String transactionId, String password, OcrCallbackRequest request);
}
