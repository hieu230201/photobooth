package com.example.codexdemo.service;

import com.example.codexdemo.dto.request.ocr.OcrAsyncFlowRequest;
import com.example.codexdemo.dto.response.ocr.OcrAsyncFlowResponse;

public interface OcrFlowService {

    OcrAsyncFlowResponse submitAsyncFlow(OcrAsyncFlowRequest request);
}
