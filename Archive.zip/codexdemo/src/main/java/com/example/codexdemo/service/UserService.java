package com.example.codexdemo.service;

import com.example.codexdemo.dto.request.CreateUserRequest;
import com.example.codexdemo.dto.request.UpdateUserRequest;
import com.example.codexdemo.dto.response.UserResponse;
import java.util.List;

public interface UserService {

    UserResponse createUser(CreateUserRequest request);

    List<UserResponse> getUsers();

    UserResponse getUserById(Long id);

    UserResponse updateUser(Long id, UpdateUserRequest request);

    void deleteUser(Long id);
}
