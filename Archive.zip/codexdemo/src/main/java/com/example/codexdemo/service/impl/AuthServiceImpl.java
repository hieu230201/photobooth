package com.example.codexdemo.service.impl;

import com.example.codexdemo.common.SecurityConstants;
import com.example.codexdemo.dto.request.LoginRequest;
import com.example.codexdemo.dto.response.LoginResponse;
import com.example.codexdemo.dto.response.LogoutResponse;
import com.example.codexdemo.dto.response.UserProfileResponse;
import com.example.codexdemo.entity.RevokedTokenEntity;
import com.example.codexdemo.entity.UserEntity;
import com.example.codexdemo.exception.AuthenticationFailedException;
import com.example.codexdemo.exception.UnauthorizedException;
import com.example.codexdemo.repository.RevokedTokenRepository;
import com.example.codexdemo.repository.UserRepository;
import com.example.codexdemo.security.JwtService;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import java.time.OffsetDateTime;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Service
@RequiredArgsConstructor
public class AuthServiceImpl implements com.example.codexdemo.service.AuthService {

    private final UserRepository userRepository;
    private final RevokedTokenRepository revokedTokenRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;

    @Override
    @Transactional(readOnly = true)
    public LoginResponse login(LoginRequest request) {
        UserEntity user = userRepository.findByUsername(request.username())
                .filter(UserEntity::isEnabled)
                .orElseThrow(() -> new AuthenticationFailedException("Invalid username or password"));

        if (!passwordEncoder.matches(request.password(), user.getPasswordHash())) {
            throw new AuthenticationFailedException("Invalid username or password");
        }

        JwtService.TokenDetails tokenDetails = jwtService.generateAccessToken(user);
        log.info("User login traceId={}, username={}", MDC.get(SecurityConstants.TRACE_ID), user.getUsername());
        return new LoginResponse(
                tokenDetails.token(),
                SecurityConstants.TOKEN_TYPE,
                tokenDetails.issuer(),
                tokenDetails.subject(),
                tokenDetails.jwtId(),
                tokenDetails.issuedAt(),
                tokenDetails.expiresAt(),
                new UserProfileResponse(
                        user.getId(),
                        user.getUsername(),
                        user.getFullName(),
                        user.getRoles().stream().map(role -> role.getName().name()).collect(java.util.stream.Collectors.toSet())
                )
        );
    }

    @Override
    @Transactional
    public LogoutResponse logout(String accessToken) {
        if (accessToken == null || accessToken.isBlank()) {
            throw new UnauthorizedException("Access token is required");
        }

        try {
            Claims claims = jwtService.parseToken(accessToken);
            if (!revokedTokenRepository.existsByJti(claims.getId())) {
                revokedTokenRepository.save(new RevokedTokenEntity(
                        claims.getId(),
                        OffsetDateTime.ofInstant(claims.getExpiration().toInstant(), java.time.ZoneOffset.UTC)
                ));
            }
            log.info("User logout traceId={}, subject={}", MDC.get(SecurityConstants.TRACE_ID), claims.getSubject());
            return new LogoutResponse("LOGGED_OUT");
        } catch (JwtException exception) {
            throw new UnauthorizedException("Invalid access token");
        }
    }
}
