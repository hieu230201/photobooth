package com.example.codexdemo.service.impl;

import com.example.codexdemo.common.SecurityConstants;
import com.example.codexdemo.dto.request.hoso.AtkqDoiChieuRequest;
import com.example.codexdemo.dto.request.hoso.AtkqMoneyInfoRequest;
import com.example.codexdemo.dto.request.hoso.AtkqVaultExportInfoRequest;
import com.example.codexdemo.dto.request.hoso.HosoAtkqSaveRequest;
import com.example.codexdemo.dto.request.hoso.HosoPdttSaveRequest;
import com.example.codexdemo.entity.HosoIntegrationEntity;
import com.example.codexdemo.entity.HosoSourceType;
import com.example.codexdemo.exception.ValidationException;
import com.example.codexdemo.repository.HosoIntegrationRepository;
import com.example.codexdemo.service.HosoIntegrationService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Locale;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Service
@RequiredArgsConstructor
public class HosoIntegrationServiceImpl implements HosoIntegrationService {

    private static final String BM_DIEU_CHUYEN_QUY = "BM_dieu_chuyen_quy";
    private static final String BM_TIEP_QUY = "BM_tiep_quy";
    private static final String BM_KIEM_QUY = "BM_kiem_quy";
    private static final DateTimeFormatter PDTT_DATE_FORMAT = DateTimeFormatter.ISO_LOCAL_DATE;
    private static final DateTimeFormatter ATKQ_DATE_FORMAT_SLASH = DateTimeFormatter.ofPattern("dd/MM/yyyy", Locale.ROOT);
    private static final DateTimeFormatter ATKQ_DATE_FORMAT_DASH = DateTimeFormatter.ofPattern("dd-MM-yyyy", Locale.ROOT);

    private final HosoIntegrationRepository hosoIntegrationRepository;
    private final ObjectMapper objectMapper;

    @Override
    @Transactional
    public boolean savePdtt(HosoPdttSaveRequest request) {
        validatePdtt(request);
        hosoIntegrationRepository.save(new HosoIntegrationEntity(
                HosoSourceType.PDTT,
                request.loaiNghiepVu(),
                request.requestID(),
                String.join(",", request.ref()),
                request.file(),
                request.maChiNhanh(),
                request.kySo(),
                serialize(request),
                serialize(request)
        ));
        log.info("Saved PDTT dossier traceId={}, requestId={}, branchCode={}",
                currentTraceId(), request.requestID(), request.maChiNhanh());
        return true;
    }

    @Override
    @Transactional
    public boolean saveAtkq(HosoAtkqSaveRequest request) {
        validateAtkq(request);
        hosoIntegrationRepository.save(new HosoIntegrationEntity(
                HosoSourceType.ATKQ,
                request.maYeuCau(),
                request.loaiYeuCau(),
                request.data().stream().map(reference -> reference.refFcc()).findFirst().orElse(null),
                request.path(),
                request.data().stream().map(reference -> reference.maChiNhanh()).filter(this::hasText).findFirst().orElse(null),
                null,
                serialize(request.datadoichieu()),
                serialize(request)
        ));
        log.info("Saved ATKQ dossier traceId={}, maYeuCau={}, references={}",
                currentTraceId(), request.maYeuCau(), request.data().size());
        return true;
    }

    private void validatePdtt(HosoPdttSaveRequest request) {
        parsePdttDate(request.ngayChungTu());
    }

    private void validateAtkq(HosoAtkqSaveRequest request) {
        AtkqDoiChieuRequest doiChieu = request.datadoichieu();
        if (!request.maYeuCau().equals(doiChieu.datadoichieu())) {
            throw new ValidationException("datadoichieu must match maYeuCau");
        }

        switch (request.maYeuCau()) {
            case BM_DIEU_CHUYEN_QUY -> validateDieuChuyenQuy(doiChieu);
            case BM_TIEP_QUY -> validateTiepQuy(doiChieu);
            case BM_KIEM_QUY -> validateKiemQuy(doiChieu);
            default -> throw new ValidationException("maYeuCau is not supported");
        }
    }

    private void validateDieuChuyenQuy(AtkqDoiChieuRequest request) {
        requireText(request.ngaydieuchuyen(), "ngaydieuchuyen is required for BM_dieu_chuyen_quy");
        requireText(request.donvigiao(), "donvigiao is required for BM_dieu_chuyen_quy");
        requireText(request.donvinhan(), "donvinhan is required for BM_dieu_chuyen_quy");
        validateAtkqDate(request.ngaydieuchuyen(), "ngaydieuchuyen");
        requireNonEmpty(request.thongtindieuchuyen(), "thongtindieuchuyen is required for BM_dieu_chuyen_quy");
        requireNonEmpty(request.thongtinxuatkho(), "thongtinxuatkho is required for BM_dieu_chuyen_quy");
        request.thongtindieuchuyen().forEach(item -> {
            requireText(item.sotiendieuchuyen(), "sotiendieuchuyen is required for BM_dieu_chuyen_quy");
            requireText(item.loaitien(), "loaitien is required for BM_dieu_chuyen_quy");
        });
        request.thongtinxuatkho().forEach(item -> {
            requireText(item.sotienxuatkho(), "sotienxuatkho is required for BM_dieu_chuyen_quy");
            requireText(item.loaitienxuatkho(), "loaitienxuatkho is required for BM_dieu_chuyen_quy");
            requireText(item.sotiennopvuot(), "sotiennopvuot is required for BM_dieu_chuyen_quy");
            requireText(item.loaitiennopvuot(), "loaitiennopvuot is required for BM_dieu_chuyen_quy");
        });
    }

    private void validateTiepQuy(AtkqDoiChieuRequest request) {
        requireText(request.ngaytiepquy(), "ngaytiepquy is required for BM_tiep_quy");
        requireText(request.hotennaptien1(), "hotennaptien1 is required for BM_tiep_quy");
        requireText(request.hotennaptien2(), "hotennaptien2 is required for BM_tiep_quy");
        requireText(request.hotenks(), "hotenks is required for BM_tiep_quy");
        requireNonEmpty(request.thanhviennhomtiepquy(), "thanhviennhomtiepquy is required for BM_tiep_quy");
        requireText(request.tenmaytiepquy(), "tenmaytiepquy is required for BM_tiep_quy");
        requireText(request.mamaytiepquy(), "mamaytiepquy is required for BM_tiep_quy");
        requireText(request.sotientiepquy(), "sotientiepquy is required for BM_tiep_quy");
        requireNonEmpty(request.soseri(), "soseri is required for BM_tiep_quy");
        validateAtkqDate(request.ngaytiepquy(), "ngaytiepquy");
    }

    private void validateKiemQuy(AtkqDoiChieuRequest request) {
        requireText(request.ngaykiemquy(), "ngaykiemquy is required for BM_kiem_quy");
        requireText(request.tenmaykiemquy(), "tenmaykiemquy is required for BM_kiem_quy");
        requireText(request.mamaykiemquy(), "mamaykiemquy is required for BM_kiem_quy");
        requireText(request.sotienkiemquy(), "sotienkiemquy is required for BM_kiem_quy");
        requireText(request.sotaikhoanmay(), "sotaikhoanmay is required for BM_kiem_quy");
        requireText(request.chenhlech(), "chenhlech is required for BM_kiem_quy");
        requireText(request.hotenkiemquy1(), "hotenkiemquy1 is required for BM_kiem_quy");
        requireText(request.hotenkiemquy2(), "hotenkiemquy2 is required for BM_kiem_quy");
        validateAtkqDate(request.ngaykiemquy(), "ngaykiemquy");
    }

    private LocalDate parsePdttDate(String value) {
        try {
            return LocalDate.parse(value, PDTT_DATE_FORMAT);
        } catch (DateTimeParseException exception) {
            throw new ValidationException("ngayChungTu must follow yyyy-MM-dd");
        }
    }

    private void validateAtkqDate(String value, String fieldName) {
        try {
            if (value.contains("/")) {
                LocalDate.parse(value, ATKQ_DATE_FORMAT_SLASH);
                return;
            }
            LocalDate.parse(value, ATKQ_DATE_FORMAT_DASH);
        } catch (DateTimeParseException exception) {
            throw new ValidationException(fieldName + " must follow dd/MM/yyyy or dd-MM-yyyy");
        }
    }

    private void requireText(String value, String message) {
        if (!hasText(value)) {
            throw new ValidationException(message);
        }
    }

    private void requireNonEmpty(List<?> values, String message) {
        if (values == null || values.isEmpty()) {
            throw new ValidationException(message);
        }
    }

    private boolean hasText(String value) {
        return value != null && !value.isBlank();
    }

    private String serialize(Object value) {
        try {
            return objectMapper.writeValueAsString(value);
        } catch (JsonProcessingException exception) {
            throw new ValidationException("Cannot serialize dossier payload");
        }
    }

    private String currentTraceId() {
        return MDC.get(SecurityConstants.TRACE_ID);
    }
}
