package com.example.codexdemo.service.impl;

import com.example.codexdemo.config.OcrGatewayProperties;
import com.example.codexdemo.dto.request.ocr.OcrCallbackRequest;
import com.example.codexdemo.dto.response.ocr.OcrCallbackAckResponse;
import com.example.codexdemo.exception.UnauthorizedException;
import com.example.codexdemo.exception.ValidationException;
import com.example.codexdemo.service.OcrCallbackService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Service
@RequiredArgsConstructor
public class OcrCallbackServiceImpl implements OcrCallbackService {

    private static final String TRACE_ID = "traceId";

    private final OcrGatewayProperties properties;

    @Override
    @Transactional(readOnly = true)
    public OcrCallbackAckResponse processCallback(String user, String transactionId, String password, OcrCallbackRequest request) {
        validateHeaders(user, transactionId, password);
        log.info("OCR callback received traceId={}, transactionId={}, refNo={}, documentType={}, status={}",
                MDC.get(TRACE_ID), transactionId, request.getRefNo(), request.getDocumentType(), request.getStatus());
        return new OcrCallbackAckResponse(transactionId, request.getRefNo(), request.getDocumentType(), request.getStatus());
    }

    private void validateHeaders(String user, String transactionId, String password) {
        if (transactionId == null || transactionId.isBlank()) {
            throw new ValidationException("Transactionsid header is required");
        }
        if (properties.callbackUser() != null && !properties.callbackUser().isBlank()
                && !properties.callbackUser().equals(user)) {
            throw new UnauthorizedException("Invalid callback user");
        }
        if (properties.callbackPassword() != null && !properties.callbackPassword().isBlank()
                && !properties.callbackPassword().equals(password)) {
            throw new UnauthorizedException("Invalid callback password");
        }
    }
}
