package com.example.codexdemo.service.impl;

import com.example.codexdemo.client.OcrGatewayClient;
import com.example.codexdemo.common.OcrDocumentType;
import com.example.codexdemo.common.SecurityConstants;
import com.example.codexdemo.dto.request.ocr.GatewayOcrAsyncRequest;
import com.example.codexdemo.dto.request.ocr.OcrAsyncFlowRequest;
import com.example.codexdemo.dto.response.ocr.GatewayApiResponse;
import com.example.codexdemo.dto.response.ocr.GatewayLoginData;
import com.example.codexdemo.dto.response.ocr.GatewayUploadResponse;
import com.example.codexdemo.dto.response.ocr.OcrAsyncFlowResponse;
import com.example.codexdemo.dto.response.ocr.OcrSubmissionResponse;
import com.example.codexdemo.exception.ValidationException;
import com.example.codexdemo.service.OcrFlowService;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

@Slf4j
@Service
@RequiredArgsConstructor
public class OcrFlowServiceImpl implements OcrFlowService {

    private final OcrGatewayClient ocrGatewayClient;

    @Override
    @Transactional(readOnly = true)
    public OcrAsyncFlowResponse submitAsyncFlow(OcrAsyncFlowRequest request) {
        validateRequest(request);
        OcrDocumentType documentType = OcrDocumentType.fromCode(request.type());
        GatewayLoginData loginData = ocrGatewayClient.login();
        List<GatewayUploadResponse> uploadedFiles = ocrGatewayClient.uploadFiles(loginData.accessToken(), request.files());

        List<OcrSubmissionResponse> submissions = uploadedFiles.stream()
                .map(file -> submitSingleFile(loginData.accessToken(), request.refNo(), documentType, file))
                .toList();

        log.info("OCR async flow submitted traceId={}, refNo={}, type={}, fileCount={}",
                MDC.get(SecurityConstants.TRACE_ID), request.refNo(), documentType.code(), submissions.size());
        return new OcrAsyncFlowResponse(request.refNo(), documentType.code(), submissions);
    }

    private OcrSubmissionResponse submitSingleFile(String accessToken,
                                                   String refNo,
                                                   OcrDocumentType documentType,
                                                   GatewayUploadResponse file) {
        GatewayApiResponse<String> response = ocrGatewayClient.submitAsync(
                accessToken,
                new GatewayOcrAsyncRequest(file.fileId(), refNo, documentType.code()));
        return new OcrSubmissionResponse(
                response.uuid(),
                response.data(),
                file.fileId(),
                file.sourceFileName(),
                documentType.callbackDocumentType());
    }

    private void validateRequest(OcrAsyncFlowRequest request) {
        if (request.refNo() == null || request.refNo().isBlank()) {
            throw new ValidationException("refNo must not be blank");
        }
        if (request.type() == null || request.type().isBlank()) {
            throw new ValidationException("type must not be blank");
        }
        if (request.files() == null || request.files().isEmpty()) {
            throw new ValidationException("files must not be empty");
        }
        boolean hasEmptyFile = request.files().stream().anyMatch(MultipartFile::isEmpty);
        if (hasEmptyFile) {
            throw new ValidationException("files must not contain empty file");
        }
    }
}
