package com.example.codexdemo.service.impl;

import com.example.codexdemo.dto.request.CreateUserRequest;
import com.example.codexdemo.dto.request.UpdateUserRequest;
import com.example.codexdemo.dto.response.UserResponse;
import com.example.codexdemo.entity.RoleEntity;
import com.example.codexdemo.entity.RoleName;
import com.example.codexdemo.entity.UserEntity;
import com.example.codexdemo.exception.ConflictException;
import com.example.codexdemo.exception.ResourceNotFoundException;
import com.example.codexdemo.repository.RoleRepository;
import com.example.codexdemo.repository.UserRepository;
import com.example.codexdemo.service.UserService;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    @Transactional
    public UserResponse createUser(CreateUserRequest request) {
        if (userRepository.existsByUsername(request.username())) {
            throw new ConflictException("Username already exists");
        }

        UserEntity user = new UserEntity(
                request.username(),
                passwordEncoder.encode(request.password()),
                request.fullName(),
                request.enabled(),
                resolveRoles(request.roles())
        );
        return toResponse(userRepository.save(user));
    }

    @Override
    @Transactional(readOnly = true)
    public List<UserResponse> getUsers() {
        return userRepository.findAll().stream()
                .map(this::toResponse)
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public UserResponse getUserById(Long id) {
        return toResponse(findUser(id));
    }

    @Override
    @Transactional
    public UserResponse updateUser(Long id, UpdateUserRequest request) {
        UserEntity user = findUser(id);
        if (userRepository.existsByUsernameAndIdNot(request.username(), id)) {
            throw new ConflictException("Username already exists");
        }

        user.updateUsername(request.username());
        user.updateProfile(request.fullName(), request.enabled(), resolveRoles(request.roles()));
        if (request.password() != null && !request.password().isBlank()) {
            user.updatePasswordHash(passwordEncoder.encode(request.password()));
        }
        return toResponse(userRepository.save(user));
    }

    @Override
    @Transactional
    public void deleteUser(Long id) {
        UserEntity user = findUser(id);
        userRepository.delete(user);
    }

    private UserEntity findUser(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
    }

    private Set<RoleEntity> resolveRoles(Set<RoleName> roleNames) {
        return roleNames.stream()
                .map(roleName -> roleRepository.findByName(roleName)
                        .orElseThrow(() -> new ResourceNotFoundException("Role not found: " + roleName)))
                .collect(Collectors.toSet());
    }

    private UserResponse toResponse(UserEntity user) {
        return new UserResponse(
                user.getId(),
                user.getUsername(),
                user.getFullName(),
                user.isEnabled(),
                user.getRoles().stream().map(role -> role.getName().name()).collect(Collectors.toSet()),
                user.getCreatedAt(),
                user.getUpdatedAt()
        );
    }
}
