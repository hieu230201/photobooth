package com.example.codexdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CodexdemoApplicationTests {

    @Test
    void contextLoads() {
    }
}
