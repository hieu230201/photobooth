package com.example.codexdemo.controller;

import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers.springSecurity;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.user;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.containsString;

import com.example.codexdemo.CodexdemoApplication;
import com.example.codexdemo.common.SecurityConstants;
import com.example.codexdemo.dto.request.LoginRequest;
import com.example.codexdemo.dto.response.LoginResponse;
import com.example.codexdemo.dto.response.LogoutResponse;
import com.example.codexdemo.dto.response.UserProfileResponse;
import com.example.codexdemo.exception.AuthenticationFailedException;
import com.example.codexdemo.exception.UnauthorizedException;
import com.example.codexdemo.service.AuthService;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.OffsetDateTime;
import java.util.Set;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.context.WebApplicationContext;

@SpringBootTest(classes = CodexdemoApplication.class, webEnvironment = SpringBootTest.WebEnvironment.MOCK)
class AuthControllerTest {

    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private WebApplicationContext webApplicationContext;

    @MockitoBean
    private AuthService authService;

    @BeforeEach
    void setUp() {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(this.webApplicationContext)
                .apply(springSecurity())
                .build();
    }

    @Test
    void loginReturnsSuccessPayload() throws Exception {
        LoginResponse response = new LoginResponse(
                "jwt-token",
                "Bearer",
                "codexdemo-auth",
                "admin",
                "jwt-id-001",
                OffsetDateTime.parse("2026-04-06T09:00:00Z"),
                OffsetDateTime.parse("2026-04-06T09:15:00Z"),
                new UserProfileResponse(1L, "admin", "System Administrator", Set.of("ADMIN", "USER"))
        );
        when(authService.login(eq(new LoginRequest("admin", "Admin@123")))).thenReturn(response);

        mockMvc.perform(post("/api/v1/auth/login")
                        .contentType(APPLICATION_JSON)
                        .header(SecurityConstants.TRACE_ID_HEADER, "login-trace")
                        .content(objectMapper.writeValueAsString(new LoginRequest("admin", "Admin@123"))))
                .andExpect(status().isOk())
                .andExpect(header().string(SecurityConstants.TRACE_ID_HEADER, "login-trace"))
                .andExpect(jsonPath("$.code").value("00"))
                .andExpect(jsonPath("$.message").value("Login successful"))
                .andExpect(jsonPath("$.traceId").value("login-trace"))
                .andExpect(jsonPath("$.data.accessToken").value("jwt-token"))
                .andExpect(jsonPath("$.data.user.username").value("admin"))
                .andExpect(jsonPath("$.timestamp").exists());
    }

    @Test
    void loginReturnsValidationError() throws Exception {
        mockMvc.perform(post("/api/v1/auth/login")
                        .contentType(APPLICATION_JSON)
                        .header(SecurityConstants.TRACE_ID_HEADER, "validation-trace")
                        .content("""
                                {
                                  "username": "",
                                  "password": ""
                                }
                                """))
                .andExpect(status().isBadRequest())
                .andExpect(header().string(SecurityConstants.TRACE_ID_HEADER, "validation-trace"))
                .andExpect(jsonPath("$.errorCode").value("01"))
                .andExpect(jsonPath("$.message").value(allOf(
                        containsString("username must not be blank"),
                        containsString("password must not be blank"))))
                .andExpect(jsonPath("$.traceId").value("validation-trace"))
                .andExpect(jsonPath("$.timestamp").exists());
    }

    @Test
    void loginReturnsAuthenticationFailedError() throws Exception {
        when(authService.login(eq(new LoginRequest("admin", "wrong-password"))))
                .thenThrow(new AuthenticationFailedException("Invalid username or password"));

        mockMvc.perform(post("/api/v1/auth/login")
                        .contentType(APPLICATION_JSON)
                        .header(SecurityConstants.TRACE_ID_HEADER, "auth-failed-trace")
                        .content("""
                                {
                                  "username": "admin",
                                  "password": "wrong-password"
                                }
                                """))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.errorCode").value("02"))
                .andExpect(jsonPath("$.message").value("Invalid username or password"))
                .andExpect(jsonPath("$.traceId").value("auth-failed-trace"));
    }

    @Test
    void logoutReturnsSuccessPayload() throws Exception {
        when(authService.logout("jwt-token")).thenReturn(new LogoutResponse("LOGGED_OUT"));

        mockMvc.perform(post("/api/v1/auth/logout")
                        .with(user("admin").authorities(new SimpleGrantedAuthority("ROLE_ADMIN")))
                        .header(SecurityConstants.AUTHORIZATION_HEADER, "Bearer jwt-token")
                        .header(SecurityConstants.TRACE_ID_HEADER, "logout-trace"))
                .andExpect(status().isOk())
                .andExpect(header().string(SecurityConstants.TRACE_ID_HEADER, "logout-trace"))
                .andExpect(jsonPath("$.code").value("00"))
                .andExpect(jsonPath("$.message").value("Logout successful"))
                .andExpect(jsonPath("$.traceId").value("logout-trace"))
                .andExpect(jsonPath("$.data.status").value("LOGGED_OUT"));

        verify(authService).logout("jwt-token");
    }

    @Test
    void logoutRequiresAuthentication() throws Exception {
        mockMvc.perform(post("/api/v1/auth/logout")
                        .header(SecurityConstants.TRACE_ID_HEADER, "logout-unauthorized"))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.errorCode").value("03"))
                .andExpect(jsonPath("$.message").value("Authentication is required"))
                .andExpect(jsonPath("$.traceId").value("logout-unauthorized"));
    }

    @Test
    void logoutReturnsUnauthorizedWhenServiceRejectsToken() throws Exception {
        when(authService.logout("bad-token")).thenThrow(new UnauthorizedException("Invalid access token"));

        mockMvc.perform(post("/api/v1/auth/logout")
                        .with(user("admin").authorities(new SimpleGrantedAuthority("ROLE_ADMIN")))
                        .header(SecurityConstants.AUTHORIZATION_HEADER, "Bearer bad-token")
                        .header(SecurityConstants.TRACE_ID_HEADER, "logout-invalid-trace"))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.errorCode").value("03"))
                .andExpect(jsonPath("$.message").value("Invalid access token"))
                .andExpect(jsonPath("$.traceId").value("logout-invalid-trace"));
    }
}
