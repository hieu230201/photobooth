package com.example.codexdemo.controller;

import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers.springSecurity;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import static org.hamcrest.Matchers.containsString;

import com.example.codexdemo.CodexdemoApplication;
import com.example.codexdemo.common.SecurityConstants;
import com.example.codexdemo.dto.request.hoso.AtkqDoiChieuRequest;
import com.example.codexdemo.dto.request.hoso.AtkqMoneyInfoRequest;
import com.example.codexdemo.dto.request.hoso.AtkqReferenceRequest;
import com.example.codexdemo.dto.request.hoso.AtkqVaultExportInfoRequest;
import com.example.codexdemo.dto.request.hoso.HosoAtkqSaveRequest;
import com.example.codexdemo.dto.request.hoso.HosoPdttSaveRequest;
import com.example.codexdemo.service.HosoIntegrationService;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

@SpringBootTest(classes = CodexdemoApplication.class, webEnvironment = SpringBootTest.WebEnvironment.MOCK)
class HosoIntegrationControllerTest {

    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private WebApplicationContext webApplicationContext;

    @MockitoBean
    private HosoIntegrationService hosoIntegrationService;

    @BeforeEach
    void setUp() {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(this.webApplicationContext)
                .apply(springSecurity())
                .build();
    }

    @Test
    void savePdttReturnsSuccessPayload() throws Exception {
        HosoPdttSaveRequest request = new HosoPdttSaveRequest(
                "5",
                "PDTT20260108_001",
                List.of("REF001", "REF002"),
                "summary.pdf",
                "001",
                "2026-01-08",
                "SIGNED"
        );
        when(hosoIntegrationService.savePdtt(eq(request))).thenReturn(true);

        mockMvc.perform(post("/hoso-integration/save/hoso-pdtt")
                        .contentType(APPLICATION_JSON)
                        .header(SecurityConstants.TRACE_ID_HEADER, "hoso-pdtt-trace")
                        .header(SecurityConstants.KSS_HEADER, SecurityConstants.KSS_HEADER_VALUE)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(header().string(SecurityConstants.TRACE_ID_HEADER, "hoso-pdtt-trace"))
                .andExpect(jsonPath("$.code").value("00"))
                .andExpect(jsonPath("$.message").value("OK"))
                .andExpect(jsonPath("$.data").value(true))
                .andExpect(jsonPath("$.traceId").value("hoso-pdtt-trace"));

        verify(hosoIntegrationService).savePdtt(eq(request));
    }

    @Test
    void savePdttRejectsInvalidKssHeader() throws Exception {
        mockMvc.perform(post("/hoso-integration/save/hoso-pdtt")
                        .contentType(APPLICATION_JSON)
                        .header(SecurityConstants.TRACE_ID_HEADER, "hoso-pdtt-invalid-header")
                        .header(SecurityConstants.KSS_HEADER, "invalid-header")
                        .content("""
                                {
                                  "loaiNghiepVu": "5",
                                  "requestID": "PDTT20260108_001",
                                  "ref": ["REF001"],
                                  "file": "summary.pdf",
                                  "maChiNhanh": "001",
                                  "ngayChungTu": "2026-01-08",
                                  "kySo": "SIGNED"
                                }
                                """))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.errorCode").value("03"))
                .andExpect(jsonPath("$.message").value("Invalid X-KSS-Header"))
                .andExpect(jsonPath("$.traceId").value("hoso-pdtt-invalid-header"));
    }

    @Test
    void saveAtkqReturnsValidationErrorForMissingDatadoichieu() throws Exception {
        mockMvc.perform(post("/hoso-integration/save/hoso-atkq")
                        .contentType(APPLICATION_JSON)
                        .header(SecurityConstants.TRACE_ID_HEADER, "hoso-atkq-validation")
                        .header(SecurityConstants.KSS_HEADER, SecurityConstants.KSS_HEADER_VALUE)
                        .content("""
                                {
                                  "loaiYeuCau": "1",
                                  "path": "/ecm/bpm/accounting/summary/fileTongHop.pdf",
                                  "maYeuCau": "BM_tiep_quy",
                                  "data": [
                                    {
                                      "refFcc": "ATKQ_20260108_001",
                                      "maChiNhanh": "001",
                                      "tenChiNhanh": "CN Ha Noi"
                                    }
                                  ]
                                }
                                """))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.errorCode").value("01"))
                .andExpect(jsonPath("$.message").value(containsString("datadoichieu must not be null")))
                .andExpect(jsonPath("$.traceId").value("hoso-atkq-validation"));
    }

    @Test
    void saveAtkqReturnsSuccessPayload() throws Exception {
        HosoAtkqSaveRequest request = new HosoAtkqSaveRequest(
                "1",
                "/ecm/bpm/accounting/summary/fileTongHop.pdf",
                "BM_dieu_chuyen_quy",
                List.of(new AtkqReferenceRequest("ATKQ_20260108_001", "CN Ha Noi", "001")),
                new AtkqDoiChieuRequest(
                        "BM_dieu_chuyen_quy",
                        "16-01-2026",
                        "280 TPBank Hung Vuong",
                        "240 TPBank Hung Vuong",
                        List.of(new AtkqMoneyInfoRequest("2437971500", "VND")),
                        List.of(new AtkqVaultExportInfoRequest("2437971500", "VND", "0", "VND")),
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null
                )
        );
        when(hosoIntegrationService.saveAtkq(eq(request))).thenReturn(true);

        mockMvc.perform(post("/hoso-integration/save/hoso-atkq")
                        .contentType(APPLICATION_JSON)
                        .header(SecurityConstants.TRACE_ID_HEADER, "hoso-atkq-trace")
                        .header(SecurityConstants.KSS_HEADER, SecurityConstants.KSS_HEADER_VALUE)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(header().string(SecurityConstants.TRACE_ID_HEADER, "hoso-atkq-trace"))
                .andExpect(jsonPath("$.code").value("00"))
                .andExpect(jsonPath("$.message").value("OK"))
                .andExpect(jsonPath("$.data").value(true))
                .andExpect(jsonPath("$.traceId").value("hoso-atkq-trace"));
    }
}
