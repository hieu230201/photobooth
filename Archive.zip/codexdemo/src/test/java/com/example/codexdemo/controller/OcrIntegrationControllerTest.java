package com.example.codexdemo.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers.springSecurity;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.example.codexdemo.CodexdemoApplication;
import com.example.codexdemo.common.SecurityConstants;
import com.example.codexdemo.dto.request.ocr.OcrCallbackRequest;
import com.example.codexdemo.dto.response.ocr.OcrAsyncFlowResponse;
import com.example.codexdemo.dto.response.ocr.OcrCallbackAckResponse;
import com.example.codexdemo.dto.response.ocr.OcrSubmissionResponse;
import com.example.codexdemo.service.OcrCallbackService;
import com.example.codexdemo.service.OcrFlowService;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMultipartHttpServletRequestBuilder;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

@SpringBootTest(classes = CodexdemoApplication.class, webEnvironment = SpringBootTest.WebEnvironment.MOCK)
class OcrIntegrationControllerTest {

    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private WebApplicationContext webApplicationContext;

    @MockitoBean
    private OcrFlowService ocrFlowService;

    @MockitoBean
    private OcrCallbackService ocrCallbackService;

    @BeforeEach
    void setUp() {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(this.webApplicationContext)
                .apply(springSecurity())
                .build();
    }

    @Test
    void submitAsyncFlowReturnsSuccessPayload() throws Exception {
        MockMultipartFile file = new MockMultipartFile(
                "files",
                "statement.pdf",
                MediaType.APPLICATION_PDF_VALUE,
                "dummy-content".getBytes());
        OcrAsyncFlowResponse response = new OcrAsyncFlowResponse(
                "FCC-001",
                "dn_chuyenvon",
                List.of(new OcrSubmissionResponse(
                        "request-uuid-001",
                        "FCC-001",
                        "file-001",
                        "statement.pdf",
                        "PHIEU_DE_NGHI_DIEU_CHUYEN_VON")));
        when(ocrFlowService.submitAsyncFlow(any())).thenReturn(response);

        MockMultipartHttpServletRequestBuilder request = multipart("/api/v1/ocr/kss/async")
                .file(file)
                .param("refNo", "FCC-001")
                .param("type", "dn_chuyenvon")
                .header(SecurityConstants.TRACE_ID_HEADER, "ocr-flow-trace");
        request.with(httpRequest -> {
            httpRequest.setMethod("POST");
            return httpRequest;
        });

        mockMvc.perform(request)
                .andExpect(status().isOk())
                .andExpect(header().string(SecurityConstants.TRACE_ID_HEADER, "ocr-flow-trace"))
                .andExpect(jsonPath("$.code").value("00"))
                .andExpect(jsonPath("$.message").value("OCR asynchronous flow submitted successfully"))
                .andExpect(jsonPath("$.traceId").value("ocr-flow-trace"))
                .andExpect(jsonPath("$.data.refNo").value("FCC-001"))
                .andExpect(jsonPath("$.data.submissions[0].fileId").value("file-001"))
                .andExpect(jsonPath("$.data.submissions[0].callbackDocumentType")
                        .value("PHIEU_DE_NGHI_DIEU_CHUYEN_VON"));
    }

    @Test
    void receiveCallbackReturnsSuccessPayload() throws Exception {
        OcrCallbackAckResponse response = new OcrCallbackAckResponse(
                "12222",
                "FCC-001",
                "PHIEU_DE_NGHI_DIEU_CHUYEN_VON",
                "success");
        when(ocrCallbackService.processCallback(eq("ecm"), eq("12222"), eq("test-callback-password"), any(OcrCallbackRequest.class)))
                .thenReturn(response);

        mockMvc.perform(post("/SaveResponseGenAI")
                        .contentType(MediaType.APPLICATION_JSON)
                        .header(SecurityConstants.TRACE_ID_HEADER, "callback-trace")
                        .header("user", "ecm")
                        .header("Transactionsid", "12222")
                        .header("Password", "test-callback-password")
                        .content(objectMapper.writeValueAsString(callbackRequest())))
                .andExpect(status().isOk())
                .andExpect(header().string(SecurityConstants.TRACE_ID_HEADER, "callback-trace"))
                .andExpect(jsonPath("$.code").value("00"))
                .andExpect(jsonPath("$.message").value("OCR callback received successfully"))
                .andExpect(jsonPath("$.traceId").value("callback-trace"))
                .andExpect(jsonPath("$.data.transactionId").value("12222"))
                .andExpect(jsonPath("$.data.documentType").value("PHIEU_DE_NGHI_DIEU_CHUYEN_VON"));
    }

    @Test
    void receiveCallbackReturnsValidationError() throws Exception {
        mockMvc.perform(post("/SaveResponseGenAI")
                        .contentType(MediaType.APPLICATION_JSON)
                        .header(SecurityConstants.TRACE_ID_HEADER, "callback-validation")
                        .content("""
                                {
                                  "status": "",
                                  "message": "done",
                                  "refNo": "FCC-001",
                                  "documentType": "PHIEU_DE_NGHI_DIEU_CHUYEN_VON"
                                }
                                """))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.errorCode").value("01"))
                .andExpect(jsonPath("$.message").value("status must not be blank"))
                .andExpect(jsonPath("$.traceId").value("callback-validation"));
    }

    private OcrCallbackRequest callbackRequest() throws Exception {
        return objectMapper.readValue("""
                {
                  "status": "success",
                  "message": "kss ocr successfully",
                  "refNo": "FCC-001",
                  "documentType": "PHIEU_DE_NGHI_DIEU_CHUYEN_VON",
                  "Don_vi_giao": "202 - TPBank Nguyen Oanh"
                }
                """, OcrCallbackRequest.class);
    }
}
