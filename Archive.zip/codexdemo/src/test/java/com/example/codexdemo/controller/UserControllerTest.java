package com.example.codexdemo.controller;

import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers.springSecurity;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.user;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.containsString;

import com.example.codexdemo.CodexdemoApplication;
import com.example.codexdemo.common.SecurityConstants;
import com.example.codexdemo.dto.request.CreateUserRequest;
import com.example.codexdemo.dto.request.UpdateUserRequest;
import com.example.codexdemo.dto.response.UserResponse;
import com.example.codexdemo.entity.RoleName;
import com.example.codexdemo.exception.ConflictException;
import com.example.codexdemo.exception.ResourceNotFoundException;
import com.example.codexdemo.service.UserService;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Set;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

@SpringBootTest(classes = CodexdemoApplication.class, webEnvironment = SpringBootTest.WebEnvironment.MOCK)
class UserControllerTest {

    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private WebApplicationContext webApplicationContext;

    @MockitoBean
    private UserService userService;

    @BeforeEach
    void setUp() {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(this.webApplicationContext)
                .apply(springSecurity())
                .build();
    }

    @Test
    void createUserReturnsSuccessPayload() throws Exception {
        CreateUserRequest request = new CreateUserRequest(
                "john.doe", "Password@123", "John Doe", true, Set.of(RoleName.USER));
        when(userService.createUser(eq(request))).thenReturn(userResponse(2L, "john.doe", "John Doe", Set.of("USER")));

        mockMvc.perform(post("/api/v1/users")
                        .with(adminUser())
                        .contentType(APPLICATION_JSON)
                        .header(SecurityConstants.TRACE_ID_HEADER, "create-user-trace")
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(header().string(SecurityConstants.TRACE_ID_HEADER, "create-user-trace"))
                .andExpect(jsonPath("$.code").value("00"))
                .andExpect(jsonPath("$.message").value("User created successfully"))
                .andExpect(jsonPath("$.traceId").value("create-user-trace"))
                .andExpect(jsonPath("$.data.username").value("john.doe"))
                .andExpect(jsonPath("$.data.roles[0]").value("USER"));
    }

    @Test
    void createUserReturnsValidationError() throws Exception {
        mockMvc.perform(post("/api/v1/users")
                        .with(adminUser())
                        .contentType(APPLICATION_JSON)
                        .header(SecurityConstants.TRACE_ID_HEADER, "create-user-validation")
                        .content("""
                                {
                                  "username": "",
                                  "password": "short",
                                  "fullName": "",
                                  "enabled": true,
                                  "roles": []
                                }
                                """))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.errorCode").value("01"))
                .andExpect(jsonPath("$.message").value(allOf(
                        containsString("username must not be blank"),
                        containsString("password must be between 8 and 100 characters"),
                        containsString("fullName must not be blank"),
                        containsString("roles must not be empty"))))
                .andExpect(jsonPath("$.traceId").value("create-user-validation"));
    }

    @Test
    void createUserReturnsConflictError() throws Exception {
        CreateUserRequest request = new CreateUserRequest(
                "john.doe", "Password@123", "John Doe", true, Set.of(RoleName.USER));
        when(userService.createUser(eq(request))).thenThrow(new ConflictException("Username already exists"));

        mockMvc.perform(post("/api/v1/users")
                        .with(adminUser())
                        .contentType(APPLICATION_JSON)
                        .header(SecurityConstants.TRACE_ID_HEADER, "create-user-conflict")
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isConflict())
                .andExpect(jsonPath("$.errorCode").value("05"))
                .andExpect(jsonPath("$.message").value("Username already exists"))
                .andExpect(jsonPath("$.traceId").value("create-user-conflict"));
    }

    @Test
    void getUsersReturnsSuccessPayload() throws Exception {
        when(userService.getUsers()).thenReturn(List.of(
                userResponse(1L, "admin", "System Administrator", Set.of("ADMIN", "USER")),
                userResponse(2L, "john.doe", "John Doe", Set.of("USER"))));

        mockMvc.perform(get("/api/v1/users")
                        .with(adminUser())
                        .header(SecurityConstants.TRACE_ID_HEADER, "get-users-trace"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value("00"))
                .andExpect(jsonPath("$.message").value("Users fetched successfully"))
                .andExpect(jsonPath("$.traceId").value("get-users-trace"))
                .andExpect(jsonPath("$.data[0].username").value("admin"))
                .andExpect(jsonPath("$.data[1].username").value("john.doe"));
    }

    @Test
    void getUserByIdReturnsSuccessPayload() throws Exception {
        when(userService.getUserById(2L)).thenReturn(userResponse(2L, "john.doe", "John Doe", Set.of("USER")));

        mockMvc.perform(get("/api/v1/users/2")
                        .with(adminUser())
                        .header(SecurityConstants.TRACE_ID_HEADER, "get-user-by-id-trace"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value("00"))
                .andExpect(jsonPath("$.message").value("User fetched successfully"))
                .andExpect(jsonPath("$.traceId").value("get-user-by-id-trace"))
                .andExpect(jsonPath("$.data.id").value(2))
                .andExpect(jsonPath("$.data.username").value("john.doe"));
    }

    @Test
    void getUserByIdReturnsNotFoundError() throws Exception {
        when(userService.getUserById(999L)).thenThrow(new ResourceNotFoundException("User not found"));

        mockMvc.perform(get("/api/v1/users/999")
                        .with(adminUser())
                        .header(SecurityConstants.TRACE_ID_HEADER, "get-user-not-found"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.errorCode").value("04"))
                .andExpect(jsonPath("$.message").value("User not found"))
                .andExpect(jsonPath("$.traceId").value("get-user-not-found"));
    }

    @Test
    void updateUserReturnsSuccessPayload() throws Exception {
        UpdateUserRequest request = new UpdateUserRequest(
                "john.doe", "NewPassword@123", "John Doe Updated", true, Set.of(RoleName.USER, RoleName.ADMIN));
        when(userService.updateUser(eq(2L), eq(request)))
                .thenReturn(userResponse(2L, "john.doe", "John Doe Updated", Set.of("ADMIN", "USER")));

        mockMvc.perform(put("/api/v1/users/2")
                        .with(adminUser())
                        .contentType(APPLICATION_JSON)
                        .header(SecurityConstants.TRACE_ID_HEADER, "update-user-trace")
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value("00"))
                .andExpect(jsonPath("$.message").value("User updated successfully"))
                .andExpect(jsonPath("$.traceId").value("update-user-trace"))
                .andExpect(jsonPath("$.data.fullName").value("John Doe Updated"));
    }

    @Test
    void updateUserReturnsValidationError() throws Exception {
        mockMvc.perform(put("/api/v1/users/2")
                        .with(adminUser())
                        .contentType(APPLICATION_JSON)
                        .header(SecurityConstants.TRACE_ID_HEADER, "update-user-validation")
                        .content("""
                                {
                                  "username": "john.doe",
                                  "password": "short",
                                  "fullName": "",
                                  "enabled": true,
                                  "roles": []
                                }
                                """))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.errorCode").value("01"))
                .andExpect(jsonPath("$.message").value(allOf(
                        containsString("password must be between 8 and 100 characters"),
                        containsString("fullName must not be blank"),
                        containsString("roles must not be empty"))))
                .andExpect(jsonPath("$.traceId").value("update-user-validation"));
    }

    @Test
    void deleteUserReturnsSuccessPayload() throws Exception {
        doNothing().when(userService).deleteUser(2L);

        mockMvc.perform(delete("/api/v1/users/2")
                        .with(adminUser())
                        .header(SecurityConstants.TRACE_ID_HEADER, "delete-user-trace"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value("00"))
                .andExpect(jsonPath("$.message").value("User deleted successfully"))
                .andExpect(jsonPath("$.traceId").value("delete-user-trace"))
                .andExpect(jsonPath("$.data").isEmpty());
    }

    @Test
    void userEndpointsRequireAuthentication() throws Exception {
        mockMvc.perform(get("/api/v1/users")
                        .header(SecurityConstants.TRACE_ID_HEADER, "users-unauthorized"))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.errorCode").value("03"))
                .andExpect(jsonPath("$.message").value("Authentication is required"))
                .andExpect(jsonPath("$.traceId").value("users-unauthorized"));
    }

    @Test
    void userEndpointsRequireAdminRole() throws Exception {
        mockMvc.perform(get("/api/v1/users")
                        .with(user("basic-user").authorities(new SimpleGrantedAuthority("ROLE_USER")))
                        .header(SecurityConstants.TRACE_ID_HEADER, "users-forbidden"))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.errorCode").value("03"))
                .andExpect(jsonPath("$.message").value("Access is denied"))
                .andExpect(jsonPath("$.traceId").value("users-forbidden"));
    }

    private static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.UserRequestPostProcessor adminUser() {
        return user("admin").authorities(
                new SimpleGrantedAuthority("ROLE_ADMIN"),
                new SimpleGrantedAuthority("ROLE_USER"));
    }

    private static UserResponse userResponse(Long id, String username, String fullName, Set<String> roles) {
        return new UserResponse(
                id,
                username,
                fullName,
                true,
                roles,
                OffsetDateTime.parse("2026-04-06T09:00:00Z"),
                OffsetDateTime.parse("2026-04-06T09:15:00Z"));
    }
}
