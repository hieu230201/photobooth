package com.example.codexdemo.service;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;

import com.example.codexdemo.dto.request.hoso.AtkqDoiChieuRequest;
import com.example.codexdemo.dto.request.hoso.AtkqMoneyInfoRequest;
import com.example.codexdemo.dto.request.hoso.AtkqReferenceRequest;
import com.example.codexdemo.dto.request.hoso.AtkqVaultExportInfoRequest;
import com.example.codexdemo.dto.request.hoso.HosoAtkqSaveRequest;
import com.example.codexdemo.dto.request.hoso.HosoPdttSaveRequest;
import com.example.codexdemo.exception.ValidationException;
import com.example.codexdemo.repository.HosoIntegrationRepository;
import com.example.codexdemo.service.impl.HosoIntegrationServiceImpl;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class HosoIntegrationServiceImplTest {

    @Mock
    private HosoIntegrationRepository hosoIntegrationRepository;

    private HosoIntegrationServiceImpl hosoIntegrationService;

    @BeforeEach
    void setUp() {
        hosoIntegrationService = new HosoIntegrationServiceImpl(hosoIntegrationRepository, new ObjectMapper());
    }

    @Test
    void savePdttPersistsPayloadWhenRequestIsValid() {
        HosoPdttSaveRequest request = new HosoPdttSaveRequest(
                "5",
                "PDTT20260108_001",
                List.of("REF001", "REF002"),
                "summary.pdf",
                "001",
                "2026-01-08",
                "SIGNED"
        );

        assertTrue(hosoIntegrationService.savePdtt(request));
        verify(hosoIntegrationRepository).save(any());
    }

    @Test
    void savePdttRejectsInvalidDateFormat() {
        HosoPdttSaveRequest request = new HosoPdttSaveRequest(
                "5",
                "PDTT20260108_001",
                List.of("REF001"),
                "summary.pdf",
                "001",
                "08/01/2026",
                "SIGNED"
        );

        assertThrows(ValidationException.class, () -> hosoIntegrationService.savePdtt(request));
    }

    @Test
    void saveAtkqRejectsUnsupportedBusinessType() {
        HosoAtkqSaveRequest request = new HosoAtkqSaveRequest(
                "1",
                "/ecm/test.pdf",
                "BM_khac",
                List.of(new AtkqReferenceRequest("ATKQ_001", "CN Ha Noi", "001")),
                new AtkqDoiChieuRequest(
                        "BM_khac",
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null
                )
        );

        assertThrows(ValidationException.class, () -> hosoIntegrationService.saveAtkq(request));
    }

    @Test
    void saveAtkqPersistsPayloadForDieuChuyenQuy() {
        HosoAtkqSaveRequest request = new HosoAtkqSaveRequest(
                "1",
                "/ecm/test.pdf",
                "BM_dieu_chuyen_quy",
                List.of(new AtkqReferenceRequest("ATKQ_001", "CN Ha Noi", "001")),
                new AtkqDoiChieuRequest(
                        "BM_dieu_chuyen_quy",
                        "16/01/2026",
                        "CN giao",
                        "CN nhan",
                        List.of(new AtkqMoneyInfoRequest("1000", "VND")),
                        List.of(new AtkqVaultExportInfoRequest("1000", "VND", "0", "VND")),
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null
                )
        );

        assertTrue(hosoIntegrationService.saveAtkq(request));
        verify(hosoIntegrationRepository).save(any());
    }
}
