package com.example.codexdemo.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.example.codexdemo.client.OcrGatewayClient;
import com.example.codexdemo.dto.request.ocr.GatewayOcrAsyncRequest;
import com.example.codexdemo.dto.request.ocr.OcrAsyncFlowRequest;
import com.example.codexdemo.dto.response.ocr.GatewayApiResponse;
import com.example.codexdemo.dto.response.ocr.GatewayLoginData;
import com.example.codexdemo.dto.response.ocr.GatewayUploadResponse;
import com.example.codexdemo.dto.response.ocr.OcrAsyncFlowResponse;
import com.example.codexdemo.exception.ValidationException;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;

@ExtendWith(MockitoExtension.class)
class OcrFlowServiceImplTest {

    @Mock
    private OcrGatewayClient ocrGatewayClient;

    @InjectMocks
    private OcrFlowServiceImpl ocrFlowService;

    @Test
    void submitAsyncFlowCallsGatewayInOrderForEachUploadedFile() {
        MultipartFile firstFile = new MockMultipartFile("files", "first.pdf", "application/pdf", "a".getBytes());
        MultipartFile secondFile = new MockMultipartFile("files", "second.pdf", "application/pdf", "b".getBytes());
        OcrAsyncFlowRequest request = new OcrAsyncFlowRequest(List.of(firstFile, secondFile), "FCC-002", "dn_chuyenvon");

        when(ocrGatewayClient.login()).thenReturn(new GatewayLoginData("access-token", "refresh-token", "Bearer"));
        when(ocrGatewayClient.uploadFiles(eq("access-token"), eq(List.of(firstFile, secondFile))))
                .thenReturn(List.of(
                        new GatewayUploadResponse("file-001", "first.pdf", "ocr/first.pdf"),
                        new GatewayUploadResponse("file-002", "second.pdf", "ocr/second.pdf")));
        when(ocrGatewayClient.submitAsync(eq("access-token"), eq(new GatewayOcrAsyncRequest("file-001", "FCC-002", "dn_chuyenvon"))))
                .thenReturn(new GatewayApiResponse<>("request-001", 200, "Success", "Mon Jul 21 09:17:03 ICT 2025", "FCC-002"));
        when(ocrGatewayClient.submitAsync(eq("access-token"), eq(new GatewayOcrAsyncRequest("file-002", "FCC-002", "dn_chuyenvon"))))
                .thenReturn(new GatewayApiResponse<>("request-002", 200, "Success", "Mon Jul 21 09:17:03 ICT 2025", "FCC-002"));

        OcrAsyncFlowResponse response = ocrFlowService.submitAsyncFlow(request);

        assertEquals("FCC-002", response.refNo());
        assertEquals("dn_chuyenvon", response.type());
        assertEquals(2, response.submissions().size());
        assertEquals("request-001", response.submissions().get(0).requestId());
        assertEquals("PHIEU_DE_NGHI_DIEU_CHUYEN_VON", response.submissions().get(0).callbackDocumentType());
        assertEquals("request-002", response.submissions().get(1).requestId());
        verify(ocrGatewayClient).login();
        verify(ocrGatewayClient).uploadFiles("access-token", List.of(firstFile, secondFile));
        verify(ocrGatewayClient).submitAsync("access-token", new GatewayOcrAsyncRequest("file-001", "FCC-002", "dn_chuyenvon"));
        verify(ocrGatewayClient).submitAsync("access-token", new GatewayOcrAsyncRequest("file-002", "FCC-002", "dn_chuyenvon"));
    }

    @Test
    void submitAsyncFlowRejectsUnsupportedDocumentType() {
        MultipartFile file = new MockMultipartFile("files", "first.pdf", "application/pdf", "a".getBytes());
        OcrAsyncFlowRequest request = new OcrAsyncFlowRequest(List.of(file), "FCC-003", "unsupported");

        ValidationException exception = assertThrows(ValidationException.class, () -> ocrFlowService.submitAsyncFlow(request));

        assertEquals("Unsupported OCR document type", exception.getMessage());
    }
}
