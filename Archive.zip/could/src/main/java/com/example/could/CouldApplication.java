package com.example.could;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

@SpringBootApplication
@EnableEurekaServer
public class CouldApplication {

    public static void main(String[] args) {
        SpringApplication.run(CouldApplication.class, args);
    }

}
