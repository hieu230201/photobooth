package com.example.demoanti;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoantiApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoantiApplication.class, args);
	}

}
