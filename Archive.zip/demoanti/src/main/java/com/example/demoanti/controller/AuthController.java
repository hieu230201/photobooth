package com.example.demoanti.controller;

import com.example.demoanti.dto.request.LoginRequest;
import com.example.demoanti.dto.response.ApiResponse;
import com.example.demoanti.dto.response.LoginResponse;
import com.example.demoanti.service.AuthService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.slf4j.MDC;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;
    private static final String TRACE_ID = "traceId";

    @PostMapping("/login")
    public ResponseEntity<ApiResponse<LoginResponse>> login(@Valid @RequestBody LoginRequest loginRequest) {
        String traceId = getOrGenerateTraceId();
        LoginResponse response = authService.login(loginRequest);

        return ResponseEntity.ok(ApiResponse.<LoginResponse>builder()
                .code("00")
                .message("Login successful")
                .data(response)
                .traceId(traceId)
                .timestamp(Instant.now().toString())
                .build());
    }

    @PostMapping("/logout")
    public ResponseEntity<ApiResponse<Void>> logout(@RequestHeader("Authorization") String authHeader) {
        String traceId = getOrGenerateTraceId();
        
        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            authService.logout(authHeader.substring(7));
        }

        return ResponseEntity.ok(ApiResponse.<Void>builder()
                .code("00")
                .message("Logout successful")
                .data(null)
                .traceId(traceId)
                .timestamp(Instant.now().toString())
                .build());
    }

    private String getOrGenerateTraceId() {
        String traceId = MDC.get(TRACE_ID);
        if (traceId == null) {
            traceId = UUID.randomUUID().toString();
            MDC.put(TRACE_ID, traceId);
        }
        return traceId;
    }
}
