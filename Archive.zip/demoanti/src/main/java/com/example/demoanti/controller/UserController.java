package com.example.demoanti.controller;

import com.example.demoanti.dto.request.CreateUserRequest;
import com.example.demoanti.dto.request.UpdateUserRequest;
import com.example.demoanti.dto.response.ApiResponse;
import com.example.demoanti.dto.response.UserResponse;
import com.example.demoanti.service.UserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.slf4j.MDC;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/users")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;
    private static final String TRACE_ID = "traceId";

    @PostMapping
    public ResponseEntity<ApiResponse<UserResponse>> createUser(@Valid @RequestBody CreateUserRequest request) {
        String traceId = getOrGenerateTraceId();
        UserResponse response = userService.createUser(request);

        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.<UserResponse>builder()
                .code("00")
                .message("User created successfully")
                .data(response)
                .traceId(traceId)
                .timestamp(Instant.now().toString())
                .build());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<UserResponse>> getUserById(@PathVariable Long id) {
        String traceId = getOrGenerateTraceId();
        UserResponse response = userService.getUserById(id);

        return ResponseEntity.ok(ApiResponse.<UserResponse>builder()
                .code("00")
                .message("User retrieved successfully")
                .data(response)
                .traceId(traceId)
                .timestamp(Instant.now().toString())
                .build());
    }

    @GetMapping
    public ResponseEntity<ApiResponse<List<UserResponse>>> getAllUsers() {
        String traceId = getOrGenerateTraceId();
        List<UserResponse> response = userService.getAllUsers();

        return ResponseEntity.ok(ApiResponse.<List<UserResponse>>builder()
                .code("00")
                .message("Users retrieved successfully")
                .data(response)
                .traceId(traceId)
                .timestamp(Instant.now().toString())
                .build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<UserResponse>> updateUser(
            @PathVariable Long id, @Valid @RequestBody UpdateUserRequest request) {
        String traceId = getOrGenerateTraceId();
        UserResponse response = userService.updateUser(id, request);

        return ResponseEntity.ok(ApiResponse.<UserResponse>builder()
                .code("00")
                .message("User updated successfully")
                .data(response)
                .traceId(traceId)
                .timestamp(Instant.now().toString())
                .build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> deleteUser(@PathVariable Long id) {
        String traceId = getOrGenerateTraceId();
        userService.deleteUser(id);

        return ResponseEntity.ok(ApiResponse.<Void>builder()
                .code("00")
                .message("User deleted successfully")
                .data(null)
                .traceId(traceId)
                .timestamp(Instant.now().toString())
                .build());
    }

    private String getOrGenerateTraceId() {
        String traceId = MDC.get(TRACE_ID);
        if (traceId == null) {
            traceId = UUID.randomUUID().toString();
            MDC.put(TRACE_ID, traceId);
        }
        return traceId;
    }
}
