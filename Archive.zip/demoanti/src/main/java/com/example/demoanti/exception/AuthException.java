package com.example.demoanti.exception;

public class AuthException extends BaseBusinessException {
    public AuthException(String errorCode, String message) {
        super(errorCode, message);
    }

    public AuthException(String errorCode, String message, Throwable cause) {
        super(errorCode, message, cause);
    }
}
