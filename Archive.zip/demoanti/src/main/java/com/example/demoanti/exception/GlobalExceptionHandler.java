package com.example.demoanti.exception;

import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.Instant;
import java.util.UUID;

@Slf4j
@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final String TRACE_ID = "traceId";

    @ExceptionHandler(BaseBusinessException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ErrorResponse handleBusinessException(BaseBusinessException ex) {
        String traceId = getOrGenerateTraceId();
        log.warn("Business exception occurred: traceId={}, errorCode={}, message={}", traceId, ex.getErrorCode(), ex.getMessage());
        return ErrorResponse.builder()
                .errorCode(ex.getErrorCode())
                .message(ex.getMessage())
                .traceId(traceId)
                .timestamp(Instant.now().toString())
                .build();
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ErrorResponse handleValidationException(MethodArgumentNotValidException ex) {
        String traceId = getOrGenerateTraceId();
        String message = ex.getBindingResult().getAllErrors().get(0).getDefaultMessage();
        log.warn("Validation exception occurred: traceId={}, message={}", traceId, message);
        return ErrorResponse.builder()
                .errorCode("01")
                .message(message)
                .traceId(traceId)
                .timestamp(Instant.now().toString())
                .build();
    }

    @ExceptionHandler(AuthenticationException.class)
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    public ErrorResponse handleAuthenticationException(AuthenticationException ex) {
        String traceId = getOrGenerateTraceId();
        log.warn("Authentication failed: traceId={}, message={}", traceId, ex.getMessage());
        return ErrorResponse.builder()
                .errorCode("02")
                .message("Authentication failed: " + ex.getMessage())
                .traceId(traceId)
                .timestamp(Instant.now().toString())
                .build();
    }

    @ExceptionHandler(AccessDeniedException.class)
    @ResponseStatus(HttpStatus.FORBIDDEN)
    public ErrorResponse handleAccessDeniedException(AccessDeniedException ex) {
        String traceId = getOrGenerateTraceId();
        log.warn("Access denied: traceId={}, message={}", traceId, ex.getMessage());
        return ErrorResponse.builder()
                .errorCode("03")
                .message("Access denied")
                .traceId(traceId)
                .timestamp(Instant.now().toString())
                .build();
    }

    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ErrorResponse handleGenericException(Exception ex) {
        String traceId = getOrGenerateTraceId();
        log.error("Unhandled exception occurred: traceId={}", traceId, ex);
        return ErrorResponse.builder()
                .errorCode("99")
                .message("Internal server error")
                .traceId(traceId)
                .timestamp(Instant.now().toString())
                .build();
    }

    private String getOrGenerateTraceId() {
        String traceId = MDC.get(TRACE_ID);
        if (traceId == null) {
            traceId = UUID.randomUUID().toString();
            MDC.put(TRACE_ID, traceId);
        }
        return traceId;
    }
}
