package com.example.demoanti.exception;

public class UserNotFoundException extends BaseBusinessException {
    public UserNotFoundException(String message) {
        super("USER_404", message);
    }
}
