package com.example.demoanti.exception;

public class UsernameAlreadyExistsException extends BaseBusinessException {
    public UsernameAlreadyExistsException(String message) {
        super("USER_409", message);
    }
}
