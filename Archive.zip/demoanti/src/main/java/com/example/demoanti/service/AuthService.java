package com.example.demoanti.service;

import com.example.demoanti.dto.request.LoginRequest;
import com.example.demoanti.dto.response.LoginResponse;

public interface AuthService {
    LoginResponse login(LoginRequest loginRequest);
    void logout(String token);
}
