package com.example.demoanti.service;

import com.example.demoanti.dto.request.CreateUserRequest;
import com.example.demoanti.dto.request.UpdateUserRequest;
import com.example.demoanti.dto.response.UserResponse;

import java.util.List;

public interface UserService {
    UserResponse createUser(CreateUserRequest request);
    UserResponse getUserById(Long id);
    List<UserResponse> getAllUsers();
    UserResponse updateUser(Long id, UpdateUserRequest request);
    void deleteUser(Long id);
}
