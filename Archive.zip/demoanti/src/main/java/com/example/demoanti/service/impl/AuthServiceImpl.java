package com.example.demoanti.service.impl;

import com.example.demoanti.dto.request.LoginRequest;
import com.example.demoanti.dto.response.LoginResponse;
import com.example.demoanti.exception.AuthException;
import com.example.demoanti.security.JwtUtil;
import com.example.demoanti.service.AuthService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class AuthServiceImpl implements AuthService {

    private final AuthenticationManager authenticationManager;
    private final JwtUtil jwtUtil;

    @Override
    public LoginResponse login(LoginRequest loginRequest) {
        try {
            log.info("Attempting login for user: {}", loginRequest.getUsername());
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(
                            loginRequest.getUsername(),
                            loginRequest.getPassword()
                    )
            );

            UserDetails userDetails = (UserDetails) authentication.getPrincipal();
            String jwt = jwtUtil.generateToken(userDetails);

            List<String> roles = userDetails.getAuthorities().stream()
                    .map(GrantedAuthority::getAuthority)
                    .collect(Collectors.toList());

            log.info("Login successful for user: {}", loginRequest.getUsername());
            return LoginResponse.builder()
                    .accessToken(jwt)
                    .tokenType("Bearer")
                    .username(userDetails.getUsername())
                    .roles(roles)
                    .build();

        } catch (AuthenticationException e) {
            log.warn("Login failed for user: {}", loginRequest.getUsername());
            throw new AuthException("02", "Invalid username or password", e);
        }
    }

    @Override
    public void logout(String token) {
        // Since stateless JWT is used, the client mainly handles token invalidation by discarding it.
        // For a more comprehensive solution, a token blacklist (e.g., Redis) can be implemented here.
        log.info("Logout requested and processed");
    }
}
