package com.example.demoanti;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoantiApplicationTests {

	@Test
	void contextLoads() {
	}

}
