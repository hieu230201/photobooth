package com.example.demoanti.controller;

import com.example.demoanti.dto.request.LoginRequest;
import com.example.demoanti.dto.response.ApiResponse;
import com.example.demoanti.dto.response.LoginResponse;
import com.example.demoanti.service.AuthService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class AuthControllerTest {

    @Mock
    private AuthService authService;

    @InjectMocks
    private AuthController authController;

    @BeforeEach
    void setUp() {
    }

    @Test
    void login_Success() {
        LoginRequest request = new LoginRequest("testuser", "password");
        LoginResponse response = LoginResponse.builder().accessToken("test-token").build();

        when(authService.login(any(LoginRequest.class))).thenReturn(response);

        ResponseEntity<ApiResponse<LoginResponse>> result = authController.login(request);

        assertEquals(200, result.getStatusCode().value());
        assertNotNull(result.getBody());
        assertEquals("00", result.getBody().getCode());
        assertEquals("Login successful", result.getBody().getMessage());
        assertEquals("test-token", result.getBody().getData().getAccessToken());
        assertNotNull(result.getBody().getTraceId());
        assertNotNull(result.getBody().getTimestamp());
    }

    @Test
    void logout_Success() {
        doNothing().when(authService).logout(anyString());

        ResponseEntity<ApiResponse<Void>> result = authController.logout("Bearer test-token");

        assertEquals(200, result.getStatusCode().value());
        assertNotNull(result.getBody());
        assertEquals("00", result.getBody().getCode());
        assertEquals("Logout successful", result.getBody().getMessage());
        assertNotNull(result.getBody().getTraceId());
        assertNotNull(result.getBody().getTimestamp());
    }
}
