package com.example.demoanti.controller;

import com.example.demoanti.dto.request.CreateUserRequest;
import com.example.demoanti.dto.request.UpdateUserRequest;
import com.example.demoanti.dto.response.ApiResponse;
import com.example.demoanti.dto.response.UserResponse;
import com.example.demoanti.service.UserService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;

@ExtendWith(MockitoExtension.class)
public class UserControllerTest {

    @Mock
    private UserService userService;

    @InjectMocks
    private UserController userController;

    @Test
    void createUser_Success() {
        CreateUserRequest request = new CreateUserRequest();
        request.setUsername("testuser");
        request.setPassword("password");
        request.setRoles(Collections.singleton("ROLE_USER"));
        
        UserResponse mockResponse = new UserResponse();
        mockResponse.setId(1L);
        mockResponse.setUsername("testuser");
        mockResponse.setRoles(Collections.singleton("ROLE_USER"));
        
        Mockito.when(userService.createUser(any(CreateUserRequest.class))).thenReturn(mockResponse);

        ResponseEntity<ApiResponse<UserResponse>> result = userController.createUser(request);

        assertEquals(201, result.getStatusCode().value());
        assertNotNull(result.getBody());
        assertEquals("00", result.getBody().getCode());
        assertEquals("User created successfully", result.getBody().getMessage());
        assertEquals(1L, result.getBody().getData().getId());
        assertEquals("testuser", result.getBody().getData().getUsername());
        assertNotNull(result.getBody().getTraceId());
    }

    @Test
    void getUserById_Success() {
        UserResponse mockResponse = new UserResponse();
        mockResponse.setId(1L);
        mockResponse.setUsername("testuser");
        
        Mockito.when(userService.getUserById(1L)).thenReturn(mockResponse);

        ResponseEntity<ApiResponse<UserResponse>> result = userController.getUserById(1L);

        assertEquals(200, result.getStatusCode().value());
        assertNotNull(result.getBody());
        assertEquals("00", result.getBody().getCode());
        assertEquals("testuser", result.getBody().getData().getUsername());
    }

    @Test
    void getAllUsers_Success() {
        UserResponse mockResponse = new UserResponse();
        mockResponse.setId(1L);
        mockResponse.setUsername("testuser");
        
        Mockito.when(userService.getAllUsers()).thenReturn(Collections.singletonList(mockResponse));

        ResponseEntity<ApiResponse<List<UserResponse>>> result = userController.getAllUsers();

        assertEquals(200, result.getStatusCode().value());
        assertNotNull(result.getBody());
        assertEquals("00", result.getBody().getCode());
        assertEquals(1, result.getBody().getData().size());
        assertEquals("testuser", result.getBody().getData().get(0).getUsername());
    }

    @Test
    void updateUser_Success() {
        UpdateUserRequest request = new UpdateUserRequest();
        request.setRoles(Collections.singleton("ROLE_ADMIN"));
        
        UserResponse mockResponse = new UserResponse();
        mockResponse.setId(1L);
        mockResponse.setUsername("testuser");
        mockResponse.setRoles(Collections.singleton("ROLE_ADMIN"));
        
        Mockito.when(userService.updateUser(eq(1L), any(UpdateUserRequest.class))).thenReturn(mockResponse);

        ResponseEntity<ApiResponse<UserResponse>> result = userController.updateUser(1L, request);

        assertEquals(200, result.getStatusCode().value());
        assertNotNull(result.getBody());
        assertEquals("00", result.getBody().getCode());
        assertEquals("testuser", result.getBody().getData().getUsername());
    }

    @Test
    void deleteUser_Success() {
        Mockito.doNothing().when(userService).deleteUser(1L);

        ResponseEntity<ApiResponse<Void>> result = userController.deleteUser(1L);

        assertEquals(200, result.getStatusCode().value());
        assertNotNull(result.getBody());
        assertEquals("00", result.getBody().getCode());
        assertEquals("User deleted successfully", result.getBody().getMessage());
    }
}
