package com.example.demoanti.service.impl;

import com.example.demoanti.dto.request.LoginRequest;
import com.example.demoanti.dto.response.LoginResponse;
import com.example.demoanti.exception.AuthException;
import com.example.demoanti.security.JwtUtil;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collections;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class AuthServiceImplTest {

    @Mock
    private AuthenticationManager authenticationManager;

    @Mock
    private JwtUtil jwtUtil;

    @InjectMocks
    private AuthServiceImpl authService;

    @Test
    void login_Success() {
        LoginRequest request = new LoginRequest("testuser", "password");
        Authentication authentication = mock(Authentication.class);
        UserDetails userDetails = new User("testuser", "password", Collections.emptyList());

        when(authenticationManager.authenticate(any(UsernamePasswordAuthenticationToken.class))).thenReturn(authentication);
        when(authentication.getPrincipal()).thenReturn(userDetails);
        when(jwtUtil.generateToken(userDetails)).thenReturn("test-token");

        LoginResponse response = authService.login(request);

        assertNotNull(response);
        assertEquals("test-token", response.getAccessToken());
        assertEquals("Bearer", response.getTokenType());
        assertEquals("testuser", response.getUsername());
        assertTrue(response.getRoles().isEmpty());

        verify(authenticationManager).authenticate(any(UsernamePasswordAuthenticationToken.class));
        verify(jwtUtil).generateToken(userDetails);
    }

    @Test
    void login_Failure_InvalidCredentials() {
        LoginRequest request = new LoginRequest("testuser", "wrong-password");

        when(authenticationManager.authenticate(any(UsernamePasswordAuthenticationToken.class)))
                .thenThrow(new BadCredentialsException("Bad credentials"));

        AuthException exception = assertThrows(AuthException.class, () -> authService.login(request));

        assertEquals("02", exception.getErrorCode());
        assertEquals("Invalid username or password", exception.getMessage());
    }

    @Test
    void logout_Success() {
        // Logout is basically stateless and just logs
        assertDoesNotThrow(() -> authService.logout("test-token"));
    }
}
