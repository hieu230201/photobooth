package com.example.demoanti.service.impl;

import com.example.demoanti.dto.request.CreateUserRequest;
import com.example.demoanti.dto.request.UpdateUserRequest;
import com.example.demoanti.dto.response.UserResponse;
import com.example.demoanti.exception.UserNotFoundException;
import com.example.demoanti.exception.UsernameAlreadyExistsException;
import com.example.demoanti.model.Role;
import com.example.demoanti.model.User;
import com.example.demoanti.repository.RoleRepository;
import com.example.demoanti.repository.UserRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class UserServiceImplTest {

    @Mock
    private UserRepository userRepository;

    @Mock
    private RoleRepository roleRepository;

    @Mock
    private PasswordEncoder passwordEncoder;

    @InjectMocks
    private UserServiceImpl userService;

    @Test
    void createUser_Success() {
        CreateUserRequest request = new CreateUserRequest();
        request.setUsername("newuser");
        request.setPassword("password");
        request.setRoles(Collections.singleton("ROLE_USER"));

        when(userRepository.existsByUsername("newuser")).thenReturn(false);
        when(passwordEncoder.encode("password")).thenReturn("encoded_password");

        Role role = Role.builder().name("ROLE_USER").build();
        when(roleRepository.findByName("ROLE_USER")).thenReturn(Optional.of(role));

        User savedUser = User.builder()
                .id(1L)
                .username("newuser")
                .password("encoded_password")
                .roles(new HashSet<>(Collections.singleton(role)))
                .build();
        
        when(userRepository.save(any(User.class))).thenReturn(savedUser);

        UserResponse response = userService.createUser(request);

        assertNotNull(response);
        assertEquals(1L, response.getId());
        assertEquals("newuser", response.getUsername());
        assertTrue(response.getRoles().contains("ROLE_USER"));

        verify(userRepository).save(any(User.class));
    }

    @Test
    void createUser_UsernameExists() {
        CreateUserRequest request = new CreateUserRequest();
        request.setUsername("existinguser");

        when(userRepository.existsByUsername("existinguser")).thenReturn(true);

        assertThrows(UsernameAlreadyExistsException.class, () -> userService.createUser(request));

        verify(userRepository, never()).save(any(User.class));
    }

    @Test
    void getUserById_Success() {
        User user = User.builder()
                .id(1L)
                .username("testuser")
                .roles(Collections.emptySet())
                .build();

        when(userRepository.findById(1L)).thenReturn(Optional.of(user));

        UserResponse response = userService.getUserById(1L);

        assertNotNull(response);
        assertEquals("testuser", response.getUsername());
    }

    @Test
    void getUserById_NotFound() {
        when(userRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(UserNotFoundException.class, () -> userService.getUserById(1L));
    }

    @Test
    void getAllUsers_Success() {
        User user = User.builder()
                .id(1L)
                .username("testuser")
                .roles(Collections.emptySet())
                .build();

        when(userRepository.findAll()).thenReturn(Collections.singletonList(user));

        List<UserResponse> responses = userService.getAllUsers();

        assertEquals(1, responses.size());
        assertEquals("testuser", responses.get(0).getUsername());
    }

    @Test
    void updateUser_Success() {
        UpdateUserRequest request = new UpdateUserRequest();
        request.setPassword("newpassword");

        User existingUser = User.builder()
                .id(1L)
                .username("testuser")
                .password("oldpassword")
                .roles(Collections.emptySet())
                .build();

        when(userRepository.findById(1L)).thenReturn(Optional.of(existingUser));
        when(passwordEncoder.encode("newpassword")).thenReturn("encoded_newpassword");
        when(userRepository.save(any(User.class))).thenReturn(existingUser);

        UserResponse response = userService.updateUser(1L, request);

        assertNotNull(response);
        verify(userRepository).save(existingUser);
    }

    @Test
    void deleteUser_Success() {
        when(userRepository.existsById(1L)).thenReturn(true);
        doNothing().when(userRepository).deleteById(1L);

        assertDoesNotThrow(() -> userService.deleteUser(1L));

        verify(userRepository).deleteById(1L);
    }

    @Test
    void deleteUser_NotFound() {
        when(userRepository.existsById(1L)).thenReturn(false);

        assertThrows(UserNotFoundException.class, () -> userService.deleteUser(1L));

        verify(userRepository, never()).deleteById(1L);
    }
}
